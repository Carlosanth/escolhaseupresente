// ============ ESTADO E PERSISTÊNCIA ============
const MESES = ['','Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
let currentUser = null;
let usuariosCache = []; // usuários (profiles) da empresa logada — populado por carregarUsuarios()
let fornecedoresCache = []; // fornecedores da empresa logada — populado por carregarFornecedores()
let formulariosCache = []; // formulários da empresa logada — populado por carregarFormularios()
let associacoesCache = []; // associações (usuário x formulário x fornecedor) — populado por carregarAssociacoes()
let avaliacoesCache = []; // avaliações enviadas — populado por carregarAvaliacoes()
let empresaConfigCache = {
  campos_fornecedor_custom: [],
  colunas_fornecedor_visiveis: ['tipo', 'criticidade', 'email', 'cnpj', 'telefone', 'documentos'],
};

function initDB() {
  // ap_usuarios NÃO é mais seedado aqui — usuários agora são reais,
  // vêm da tabela "profiles" do Supabase (ver usuariosCache abaixo).
  // ap_formularios NÃO é mais seedado aqui — vêm do Supabase (ver formulariosCache).
  // ap_fornecedores, ap_campos_fornecedor_custom e ap_fornecedor_colunas_visiveis
  // NÃO são mais seedados aqui — vêm do Supabase (ver fornecedoresCache/empresaConfigCache).
  // ap_associacoes NÃO é mais seedado aqui — vêm do Supabase (ver associacoesCache).
  if (!localStorage.getItem('ap_matriz')) save('ap_matriz', SEED_MATRIZ);
  // ap_avaliacoes NÃO é mais seedado aqui — vêm do Supabase (ver avaliacoesCache).
  if (!localStorage.getItem('ap_logs')) save('ap_logs', []);
  if (!localStorage.getItem('ap_empresa')) save('ap_empresa', {});
  if (!localStorage.getItem('ap_textos')) save('ap_textos', getDefaultTextos());
  if (!localStorage.getItem('ap_campos_globais')) save('ap_campos_globais', [
    { chave: 'codigo', label: 'Código', valor: 'ANX.GER.076' },
    { chave: 'revisao', label: 'Revisão', valor: '12' },
  ]);

  if (!localStorage.getItem('ap_tipos_documento')) save('ap_tipos_documento', [
    'Alvará de Funcionamento', 'Alvará Sanitário', 'CRT', 'Contrato', 'Certidão Negativa de Débitos', 'AVCB'
  ]);
  if (!localStorage.getItem('ap_layout')) save('ap_layout', getLayoutDefaults());
}

function load(key) { return JSON.parse(localStorage.getItem(key) || 'null'); }
function save(key, val) { localStorage.setItem(key, JSON.stringify(val)); }

function db() {
  return {
    usuarios: usuariosCache, // real, vindo do Supabase (profiles) — ver carregarUsuarios()
    formularios: formulariosCache,
    fornecedores: fornecedoresCache,
    associacoes: associacoesCache,
    matriz: load('ap_matriz') || SEED_MATRIZ,
    avaliacoes: avaliacoesCache,
    logs: load('ap_logs') || [],
    empresa: load('ap_empresa') || {},
    textos: load('ap_textos') || getDefaultTextos(),
    camposGlobais: load('ap_campos_globais') || [],
    camposFornecedorCustom: empresaConfigCache.campos_fornecedor_custom,
    colunasFornecedorVisiveis: empresaConfigCache.colunas_fornecedor_visiveis,
    tiposDocumento: load('ap_tipos_documento') || ['Alvará de Funcionamento', 'Alvará Sanitário', 'CRT', 'Contrato', 'Certidão Negativa de Débitos', 'AVCB'],
    documentos: load('ap_documentos') || []
  };
}

function addLog(acao, detalhe) {
  const d = db();
  d.logs.unshift({
    id: 'log' + Date.now() + Math.random().toString(36).slice(2,6),
    usuario: currentUser ? currentUser.email : 'sistema',
    acao, detalhe,
    timestamp: new Date().toISOString()
  });
  save('ap_logs', d.logs);
}

function toast(msg, dur = 2800) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.style.display = 'block';
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(() => t.style.display = 'none', dur);
}

function fmtData(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString('pt-BR') + ' ' + d.toLocaleTimeString('pt-BR', {hour:'2-digit', minute:'2-digit'});
}

// ============ LOGIN ============
async function doLogin() {
  const email = document.getElementById('login-email').value.trim().toLowerCase();
  const senha = document.getElementById('login-senha').value;
  const errBox = document.getElementById('login-error');
  errBox.style.display = 'none';

  const { error: erroLogin } = await supabaseClient.auth.signInWithPassword({ email, password: senha });
  if (erroLogin) {
    errBox.textContent = 'E-mail ou senha inválidos.';
    errBox.style.display = 'block';
    return;
  }

  const ok = await carregarPerfilELogar();
  if (!ok) {
    errBox.textContent = 'Login ok, mas não encontramos seu perfil (ou está inativo). Fale com o administrador.';
    errBox.style.display = 'block';
    await supabaseClient.auth.signOut();
  }
}

// Busca o usuário autenticado no Supabase Auth, carrega o perfil dele
// (empresa, nome, papel) da tabela "profiles" e abre a tela certa.
async function carregarPerfilELogar() {
  const { data: { user } } = await supabaseClient.auth.getUser();
  if (!user) return false;

  const { data: profile, error } = await supabaseClient
    .from('profiles')
    .select('id, nome, papel, ativo, empresa_id')
    .eq('id', user.id)
    .single();

  if (error || !profile || !profile.ativo) return false;

  currentUser = { id: profile.id, email: user.email, nome: profile.nome, papel: profile.papel, empresaId: profile.empresa_id };
  addLog('login', `${currentUser.email} entrou no sistema`);

  document.getElementById('login-screen').style.display = 'none';
  document.getElementById('app').classList.add('active');

  await carregarFormularios();
  await carregarAssociacoes();
  await carregarFornecedores();

  if (currentUser.papel === 'admin') {
    await carregarUsuarios();
    await carregarEmpresaConfig();
  }
  await carregarAvaliacoes(); // depende de usuariosCache (se admin) pra resolver o e-mail de quem enviou

  if (currentUser.papel === 'admin') {
    renderAdminShell();
  } else {
    renderAvaliadorShell();
  }
  return true;
}

// Busca os usuários (profiles) reais da empresa logada no Supabase.
// Chamada no login do admin e sempre que a lista precisa ser atualizada
// (depois de criar ou ativar/desativar um usuário).
async function carregarUsuarios() {
  const { data, error } = await supabaseClient
    .from('profiles')
    .select('id, nome, email, papel, ativo')
    .eq('empresa_id', currentUser.empresaId)
    .order('nome');

  if (error) {
    console.error('Erro ao carregar usuários:', error.message);
    usuariosCache = [];
    return;
  }
  usuariosCache = data || [];
}

// Busca os formulários reais da empresa logada no Supabase.
async function carregarFormularios() {
  const { data, error } = await supabaseClient
    .from('formularios')
    .select('*')
    .eq('empresa_id', currentUser.empresaId)
    .order('nome');

  if (error) {
    console.error('Erro ao carregar formulários:', error.message);
    formulariosCache = [];
    return;
  }
  // Traduz nomes de coluna do banco pro formato que o resto do app usa.
  formulariosCache = (data || []).map(f => ({
    id: f.id,
    nome: f.nome,
    setor: f.setor,
    tipo: f.tipo,
    criterios: f.criterios || [],
    prazoEntregaDia: f.prazo_entrega_dia,
    camposExtras: f.campos_extras || [],
  }));
}

// Busca as associações (qual usuário vê qual formulário/fornecedor) da empresa.
async function carregarAssociacoes() {
  const { data, error } = await supabaseClient
    .from('associacoes')
    .select('*')
    .eq('empresa_id', currentUser.empresaId);

  if (error) {
    console.error('Erro ao carregar associações:', error.message);
    associacoesCache = [];
    return;
  }
  associacoesCache = (data || []).map(a => ({
    id: a.id,
    usuarioId: a.usuario_id,
    formularioId: a.formulario_id,
    fornecedorId: a.fornecedor_id,
  }));
}


async function carregarFornecedores() {
  const { data, error } = await supabaseClient
    .from('fornecedores')
    .select('*')
    .eq('empresa_id', currentUser.empresaId)
    .order('nome');

  if (error) {
    console.error('Erro ao carregar fornecedores:', error.message);
    fornecedoresCache = [];
    return;
  }
  // A coluna no banco chama "campos_custom" (nome do schema original);
  // o resto do app inteiro usa "extras" — só traduz aqui, num lugar só.
  fornecedoresCache = (data || []).map(f => ({ ...f, extras: f.campos_custom || {} }));
}

// Busca as avaliações enviadas da empresa (todo mundo vê pra relatório/dashboard;
// cada avaliador filtra as próprias na tela dele).
async function carregarAvaliacoes() {
  const { data, error } = await supabaseClient
    .from('avaliacoes')
    .select('*')
    .eq('empresa_id', currentUser.empresaId)
    .order('enviado_em', { ascending: false });

  if (error) {
    console.error('Erro ao carregar avaliações:', error.message);
    avaliacoesCache = [];
    return;
  }
  avaliacoesCache = (data || []).map(av => {
    // Prioridade pro e-mail GRAVADO no momento do envio (sobrevive à exclusão
    // do usuário); só cai pro join dinâmico em registros antigos sem esse campo.
    let emailAutor = av.enviado_por_email;
    if (!emailAutor) {
      emailAutor = av.usuario_id === currentUser.id ? currentUser.email : null;
      if (!emailAutor) {
        const u = usuariosCache.find(x => x.id === av.usuario_id);
        emailAutor = u ? u.email : '—';
      }
    }
    return {
      id: av.id,
      formularioId: av.formulario_id,
      fornecedorId: av.fornecedor_id,
      usuarioId: av.usuario_id,
      enviadoPor: emailAutor,
      periodo: av.periodo,
      respostas: av.respostas || {},
      nota: av.nota_media,
      semServico: av.sem_servico,
      anexos: av.anexos || [],
      obs: av.obs || '',
      justificativa: av.justificativa || '',
      enviadoEm: av.enviado_em,
      travado: av.bloqueada,
      liberadoEdicao: av.liberado_edicao,
    };
  });
}


// e colunas visíveis na listagem).
async function carregarEmpresaConfig() {
  const { data, error } = await supabaseClient
    .from('empresas')
    .select('campos_fornecedor_custom, colunas_fornecedor_visiveis')
    .eq('id', currentUser.empresaId)
    .single();

  if (error) {
    console.error('Erro ao carregar configurações da empresa:', error.message);
    return;
  }
  empresaConfigCache = {
    campos_fornecedor_custom: data.campos_fornecedor_custom || [],
    colunas_fornecedor_visiveis: data.colunas_fornecedor_visiveis || ['tipo', 'criticidade', 'email', 'cnpj', 'telefone', 'documentos'],
  };
}

async function doLogout() {
  addLog('logout', `${currentUser.email} saiu do sistema`);
  await supabaseClient.auth.signOut();
  currentUser = null;
  document.getElementById('app').classList.remove('active');
  document.getElementById('login-screen').style.display = 'flex';
  document.getElementById('login-email').value = '';
  document.getElementById('login-senha').value = '';
}

// Ao recarregar a página, o Supabase mantém a sessão salva (em localStorage,
// gerenciado por ele mesmo) — então recuperamos e já logamos de novo.
async function checkSession() {
  const { data: { session } } = await supabaseClient.auth.getSession();
  if (session) {
    await carregarPerfilELogar();
  }
}

// ============ CÁLCULO DE NOTA ============
function calcularNota(formulario, respostas) {
  // respostas: { criterioId: { opcaoIndex, naoHouve } }
  let total = 0;
  let criteriosValidos = 0;
  let todosNaoHouve = true;

  formulario.criterios.forEach(crit => {
    const resp = respostas[crit.id];
    if (!resp || resp.naoHouve) return;
    todosNaoHouve = false;
    const opcao = crit.opcoes[resp.opcaoIndex];
    if (opcao) {
      total += opcao.pontos;
      criteriosValidos++;
    }
  });

  if (todosNaoHouve) return { nota: null, semServico: true };
  return { nota: total, semServico: false };
}

function getSituacao(nota) {
  const c = db().matriz;
  if (nota === null || isNaN(nota)) return null;
  if (nota >= c.cert) return 'certificado';
  if (nota >= c.aprov) return 'aprovado';
  if (nota >= c.parcial) return 'parcial';
  return 'reprovado';
}

function badgeSit(sit) {
  const map = {
    certificado: ['badge-accent', '🏆 Certificado'],
    aprovado: ['badge-success', '✅ Aprovado'],
    parcial: ['badge-warn', '⚠️ Parcial'],
    reprovado: ['badge-danger', '❌ Reprovado']
  };
  const [cls, label] = map[sit] || ['badge-neutral', sit || '—'];
  return `<span class="badge ${cls}">${label}</span>`;
}

function getDefaultTextos() {
  return {
    'cert-prod': '{empresa} certifica que {fornecedor} nos forneceu produtos de excelente qualidade durante o período de {periodo}, obtendo nota máxima em nossa avaliação. Parabéns pelo desempenho!',
    'cert-serv': '{empresa} certifica que {fornecedor} nos prestou serviços de excelente qualidade durante o período de {periodo}, obtendo nota máxima em nossa avaliação. Parabéns pelo desempenho!',
    'aprov-prod': 'Gostaríamos de expressar nossa gratidão pela parceria contínua e pelo empenho em garantir produtos de qualidade.\n\nReferente à avaliação do período de {periodo}, sua nota foi: {nota}.\n\nEstamos à disposição para esclarecer dúvidas sobre a avaliação e apoiar no que for necessário para sua evolução.',
    'aprov-serv': 'Gostaríamos de expressar nossa gratidão pela parceria contínua e pelo empenho em garantir serviços de qualidade.\n\nReferente à avaliação do período de {periodo}, sua nota foi: {nota}.\n\nEstamos à disposição para esclarecer dúvidas sobre a avaliação e apoiar no que for necessário para sua evolução.',
    'parcial': 'Gostaríamos de expressar nossa gratidão pela parceria contínua.\n\nReferente à avaliação do período de {periodo}, sua nota foi: {nota}. Essa nota está abaixo do esperado e exige melhorias.\n\nEncorajamos a seguir aprimorando para que possam alcançar a excelência. Estamos à disposição para esclarecer dúvidas.',
    'reprov': 'Realizamos periodicamente a avaliação de nossos fornecedores.\n\nReferente à avaliação do período de {periodo}, a nota obtida foi: {nota}.\n\nEssa pontuação está abaixo do esperado e indica necessidade de melhorias urgentes. Solicitamos que nos informem, com brevidade, quais ações corretivas serão adotadas.'
  };
}

// ============ LAYOUT CONFIGURÁVEL DOS DOCUMENTOS (blocos dinâmicos) ============
// cert = certificado (paisagem, nota 10) · carta = aprovado/parcial/reprovado (retrato)
// Cada documento tem uma LISTA de blocos (não mais chaves fixas): cada bloco pode ser
// texto fixo ou uma variável dinâmica, e pode ser livremente adicionado/removido/estilizado.
function getLayoutDefaults() {
  return {
    cert: { blocos: [
      { id: 'titulo',    label: 'Título', tipo: 'fixo', conteudo: 'CERTIFICADO DE APROVAÇÃO', fonte: 'helvetica', tamanho: 26, cor: '#7c2d12', negrito: true, italico: true, align: 'center', x: 148.5, y: 38, largura: 230 },
      { id: 'saudacao',  label: 'Saudação', tipo: 'variavel', variavel: 'saudacao', fonte: 'helvetica', tamanho: 13, cor: '#282828', negrito: false, italico: false, align: 'center', x: 148.5, y: 58, largura: 200 },
      { id: 'nome',      label: 'Nome do fornecedor', tipo: 'variavel', variavel: 'fornecedor', fonte: 'helvetica', tamanho: 18, cor: '#141414', negrito: true, italico: false, align: 'center', x: 148.5, y: 80, largura: 220 },
      { id: 'corpo',     label: 'Corpo do texto', tipo: 'variavel', variavel: 'corpo_texto', fonte: 'helvetica', tamanho: 13, cor: '#323232', negrito: false, italico: false, align: 'center', x: 148.5, y: 98, largura: 177 },
      { id: 'nota',      label: 'Nota', tipo: 'variavel', variavel: 'nota', fonte: 'helvetica', tamanho: 18, cor: '#141414', negrito: true, italico: false, align: 'center', x: 148.5, y: 160, largura: 120 },
      { id: 'rodape',    label: 'Endereço (rodapé)', tipo: 'variavel', variavel: 'rodape_empresa', fonte: 'helvetica', tamanho: 8, cor: '#505050', negrito: false, italico: false, align: 'left', x: 30, y: 200, largura: 150 },
      { id: 'data',      label: 'Data/local', tipo: 'variavel', variavel: 'data_hoje', fonte: 'helvetica', tamanho: 8, cor: '#505050', negrito: false, italico: false, align: 'right', x: 267, y: 200, largura: 100 }
    ]},
    carta: { blocos: [
      { id: 'data',      label: 'Data/local', tipo: 'variavel', variavel: 'data_hoje', fonte: 'helvetica', tamanho: 10, cor: '#646464', negrito: false, italico: false, align: 'left', x: 25, y: 30, largura: 150 },
      { id: 'nome',      label: 'Nome do fornecedor', tipo: 'variavel', variavel: 'fornecedor', fonte: 'helvetica', tamanho: 13, cor: '#000000', negrito: true, italico: false, align: 'left', x: 25, y: 42, largura: 160 },
      { id: 'subtitulo', label: 'Situação (Aprovado/Parcial/Reprovado)', tipo: 'variavel', variavel: 'situacao', fonte: 'helvetica', tamanho: 12, cor: '#009942', negrito: false, italico: false, align: 'left', x: 25, y: 50, largura: 160 },
      { id: 'corpo',     label: 'Corpo do texto', tipo: 'variavel', variavel: 'corpo_texto', fonte: 'helvetica', tamanho: 11, cor: '#000000', negrito: false, italico: false, align: 'left', x: 25, y: 62, largura: 160 },
      { id: 'rodape',    label: 'Endereço (rodapé)', tipo: 'variavel', variavel: 'rodape_empresa', fonte: 'helvetica', tamanho: 9, cor: '#787878', negrito: false, italico: false, align: 'center', x: 105, y: 281, largura: 160 }
    ]}
  };
}

// Converte um layout salvo no formato antigo (objeto com chaves fixas: titulo/nome/corpo...)
// pro novo formato de blocos, preservando posição/tamanho/alinhamento que o usuário já ajustou.
function migrarLayoutAntigoParaBlocos(salvoAntigo, def) {
  const resultado = {};
  ['cert', 'carta'].forEach(tipo => {
    const antigos = salvoAntigo[tipo] || {};
    resultado[tipo] = { blocos: def[tipo].blocos.map(defBloco => {
      const antigo = antigos[defBloco.id];
      if (!antigo) return { ...defBloco };
      return { ...defBloco, x: antigo.x ?? defBloco.x, y: antigo.y ?? defBloco.y, tamanho: antigo.size ?? defBloco.tamanho, align: antigo.align ?? defBloco.align, largura: antigo.largura ?? defBloco.largura };
    })};
  });
  return resultado;
}

function getLayout() {
  const saved = load('ap_layout');
  const def = getLayoutDefaults();
  if (!saved) return JSON.parse(JSON.stringify(def));
  const formatoNovo = saved.cert && Array.isArray(saved.cert.blocos);
  if (!formatoNovo) return migrarLayoutAntigoParaBlocos(saved, def);
  return {
    cert:  { blocos: Array.isArray(saved.cert.blocos)  && saved.cert.blocos.length  ? saved.cert.blocos  : def.cert.blocos },
    carta: { blocos: Array.isArray(saved.carta.blocos) && saved.carta.blocos.length ? saved.carta.blocos : def.carta.blocos }
  };
}

// Variáveis dinâmicas disponíveis pra associar a um bloco (inclui campos personalizados do fornecedor)
function getVariaveisDoc() {
  const d = db();
  const vars = {
    fornecedor:     { label: 'Nome do fornecedor' },
    empresa:        { label: 'Nome da sua empresa' },
    nota:           { label: 'Nota final' },
    periodo:        { label: 'Período avaliado' },
    situacao:       { label: 'Situação (Aprovado/Parcial/Reprovado)' },
    cnpj:           { label: 'CNPJ do fornecedor' },
    setor:          { label: 'Setor do fornecedor' },
    criticidade:    { label: 'Criticidade do fornecedor' },
    corpo_texto:    { label: 'Texto do status (configurado em Config › Textos)' },
    saudacao:       { label: 'Saudação institucional' },
    data_hoje:      { label: 'Data de hoje (por extenso)' },
    rodape_empresa: { label: 'Endereço/contato da empresa' }
  };
  (d.camposFornecedorCustom || []).forEach(c => { vars['extra_' + c.chave] = { label: 'Campo personalizado: ' + c.label }; });
  return vars;
}

// Resolve o valor de uma variável pro texto final (usado tanto no preview do editor quanto no PDF)
function resolveVariavelValor(chave, ctx) {
  switch (chave) {
    case 'fornecedor': return ctx.fornecedor.nome + (ctx.isCert ? '' : '.');
    case 'empresa': return ctx.empresaNome;
    case 'nota': return ctx.isCert ? `NOTA: ${ctx.nota}` : ctx.nota;
    case 'periodo': return ctx.periodo;
    case 'situacao': return getSubtituloDoc(ctx.sit);
    case 'cnpj': return ctx.fornecedor.cnpj || '';
    case 'setor': return ctx.fornecedor.setor || '';
    case 'criticidade': return ctx.fornecedor.criticidade || '';
    case 'corpo_texto': return ctx.corpoTexto;
    case 'saudacao': return `${ctx.empresaNome} certifica que:`;
    case 'data_hoje': {
      const hoje = new Date();
      const txt = `${ctx.dadosEmpresa.cidade || ''}, ${hoje.getDate()} de ${MESES[hoje.getMonth()+1]} de ${hoje.getFullYear()}`;
      return ctx.isCert ? txt : txt + '.';
    }
    case 'rodape_empresa': {
      const e = ctx.dadosEmpresa;
      return ctx.isCert
        ? ([e.endereco, e.tel ? `Fones: ${e.tel}` : '', e.cep ? `CEP: ${e.cep} | ${e.cidade||''}` : e.cidade].filter(Boolean).join(' | ') || ctx.empresaNome)
        : ([e.endereco, e.cidade, e.cep ? `CEP: ${e.cep}` : '', e.tel].filter(Boolean).join(' | ') || ctx.empresaNome);
    }
    default:
      if (chave.startsWith('extra_')) return (ctx.fornecedor.extras || {})[chave.slice(6)] || '';
      return '';
  }
}

// ============ MODAL HELPERS ============
function openModal(html) {
  document.getElementById('modal-box').innerHTML = html;
  document.getElementById('modal-overlay').classList.add('active');
}
function closeModal() {
  document.getElementById('modal-overlay').classList.remove('active');
}
document.getElementById('modal-overlay').addEventListener('click', (e) => {
  if (e.target.id === 'modal-overlay') closeModal();
});

// ============ INIT ============
initDB();
checkSession();

// ============ SHELL DO AVALIADOR ============
function renderAvaliadorShell() {
  document.getElementById('sidebar').innerHTML = `
    <div class="sidebar-logo"><h1>AvaliaPro</h1><p>Área do avaliador</p></div>
    <div class="sidebar-user">
      <div class="sidebar-user-avatar">${currentUser.nome.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase()}</div>
      <div class="sidebar-user-info">
        <p>${currentUser.nome}</p>
        <span>${currentUser.email}</span><br>
        <span class="role-badge avaliador">Avaliador</span>
      </div>
    </div>
    <button class="nav-item active" onclick="showAvPage('formularios', this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
      Meus formulários
    </button>
    <button class="nav-item" onclick="showAvPage('historico', this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
      Histórico de envios
    </button>
    <div class="nav-logout">
      <button class="nav-item" onclick="doLogout()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
        Sair
      </button>
    </div>
  `;
  document.getElementById('main').innerHTML = `
    <div class="page active" id="av-page-formularios"></div>
    <div class="page" id="av-page-historico"></div>
  `;
  renderAvFormularios();
}

function showAvPage(page, btn) {
  document.querySelectorAll('#sidebar .nav-item').forEach(n => n.classList.remove('active'));
  if (btn) btn.classList.add('active');
  document.querySelectorAll('#main .page').forEach(p => p.classList.remove('active'));
  document.getElementById('av-page-' + page).classList.add('active');
  if (page === 'formularios') renderAvFormularios();
  if (page === 'historico') renderAvHistorico();
}

function renderAvFormularios() {
  const d = db();
  const mesAtual = new Date().getMonth() + 1;
  const anoAtual = new Date().getFullYear();

  const minhasAssoc = d.associacoes.filter(a => a.usuarioId === currentUser.id);

  const wrap = document.getElementById('av-page-formularios');
  if (!minhasAssoc.length) {
    wrap.innerHTML = `
      <div class="page-header"><div><h2>Meus formulários</h2><p>Nenhum formulário foi associado ao seu e-mail ainda. Fale com o administrador.</p></div></div>
      <div class="card"><div class="empty-state"><p>Sem formulários disponíveis.</p></div></div>`;
    return;
  }

  wrap.innerHTML = `
    <div class="page-header">
      <div><h2>Meus formulários</h2><p>${MESES[mesAtual]} de ${anoAtual} — clique em um formulário para avaliar</p></div>
    </div>
    <div class="forms-grid" id="av-forms-grid"></div>
  `;

  const grid = document.getElementById('av-forms-grid');
  grid.innerHTML = minhasAssoc.map(assoc => {
    const form = d.formularios.find(f => f.id === assoc.formularioId);
    if (!form) return '';
    const fornecedor = assoc.fornecedorId ? d.fornecedores.find(fn => fn.id === assoc.fornecedorId) : null;
    const chaveMes = `${anoAtual}-${mesAtual}`;
    // Pode ter MAIS DE UMA avaliação no mês (um atendimento por avaliação) —
    // pega todas e usa a mais recente pra mostrar status/nota no card.
    const avaliacoesDoMes = d.avaliacoes
      .filter(av => av.formularioId === form.id && av.fornecedorId === assoc.fornecedorId && av.usuarioId === currentUser.id && av.periodo === chaveMes)
      .sort((a, b) => new Date(b.enviadoEm) - new Date(a.enviadoEm));
    const jaPreenchido = avaliacoesDoMes[0] || null;
    const foiLiberado = jaPreenchido && jaPreenchido.liberadoEdicao;

    const camposLinha = (form.camposExtras && form.camposExtras.length)
      ? form.camposExtras.filter(c => c.valor).map(c => `${c.label}: ${c.valor}`).join(' · ')
      : '';

    let prazoLinha = '';
    if (form.prazoEntregaDia) {
      const hoje = new Date();
      const venceEsteAno = hoje.getDate() > form.prazoEntregaDia && !jaPreenchido;
      prazoLinha = `<span style="color:${venceEsteAno ? 'var(--danger)' : 'var(--text-muted)'}">Prazo: dia ${form.prazoEntregaDia}${venceEsteAno ? ' (atrasado)' : ''}</span>`;
    }

    const podeAbrirCard = !jaPreenchido || foiLiberado;
    return `
      <div class="form-card ${foiLiberado ? 'pendente' : jaPreenchido ? 'preenchido' : 'pendente'}" ${podeAbrirCard ? `onclick="abrirFormulario('${assoc.id}')" style="cursor:pointer"` : 'style="cursor:default"'}>
        <div class="form-card-top">
          <div>
            <h4>${form.nome}</h4>
            <p>${fornecedor ? fornecedor.nome : 'Fornecedor a definir'} · ${MESES[mesAtual]} de ${anoAtual}</p>
            ${camposLinha || prazoLinha ? `<p style="margin-top:4px; font-size:11px; color:var(--text-muted)">${[camposLinha, prazoLinha].filter(Boolean).join(' &nbsp;·&nbsp; ')}</p>` : ''}
          </div>
          <span class="form-card-status ${foiLiberado ? 'pending' : jaPreenchido ? 'ok' : 'pending'}">${foiLiberado ? 'Reenviar' : jaPreenchido ? 'Enviado' : 'Pendente'}</span>
        </div>
        ${jaPreenchido ? `<div style="margin-top:10px; font-size:12px; color:var(--text-muted)">${avaliacoesDoMes.length > 1 ? `${avaliacoesDoMes.length} atendimentos avaliados · ` : ''}Nota mais recente: <b style="color:var(--text)">${jaPreenchido.nota !== null ? jaPreenchido.nota.toFixed(1) : '—'}</b> · enviado em ${fmtData(jaPreenchido.enviadoEm)}</div>` : `<div style="margin-top:10px; font-size:12px; color:var(--text-muted)">Setor: ${form.setor}</div>`}
        ${jaPreenchido && !foiLiberado ? `<div style="margin-top:10px"><button class="btn btn-secondary btn-sm" onclick="event.stopPropagation(); abrirFormulario('${assoc.id}', true)">+ Avaliar outro atendimento</button></div>` : ''}
      </div>
    `;
  }).join('');
}

function abrirFormulario(assocId, forcarNovo) {
  const d = db();
  const assoc = d.associacoes.find(a => a.id === assocId);
  const form = d.formularios.find(f => f.id === assoc.formularioId);
  const fornecedor = assoc.fornecedorId ? d.fornecedores.find(fn => fn.id === assoc.fornecedorId) : null;
  const mesAtual = new Date().getMonth() + 1;
  const anoAtual = new Date().getFullYear();
  const chaveMes = `${anoAtual}-${mesAtual}`;

  const encontrada = d.avaliacoes
    .filter(av => av.formularioId === form.id && av.fornecedorId === assoc.fornecedorId && av.usuarioId === currentUser.id && av.periodo === chaveMes)
    .sort((a, b) => new Date(b.enviadoEm) - new Date(a.enviadoEm))[0] || null;
  // forcarNovo = "Avaliar outro atendimento": ignora o que já existe, abre em branco,
  // e o envio vira um registro NOVO (não sobrescreve o atendimento anterior).
  const existente = forcarNovo ? null : encontrada;
  // Se admin liberou edição, tratar como "não enviado" visualmente
  const liberado = existente && existente.liberadoEdicao;
  const travado = existente && existente.travado && !liberado;

  const wrap = document.getElementById('av-page-formularios');
  wrap.innerHTML = `
    <div class="page-header">
      <div>
        <h2>${form.nome}</h2>
        <p>${fornecedor ? fornecedor.nome + ' · ' : ''}${MESES[mesAtual]} de ${anoAtual}${forcarNovo ? ' · novo atendimento' : ''}</p>
      </div>
      <button class="btn btn-secondary btn-sm" onclick="renderAvFormularios()">← Voltar</button>
    </div>
    ${travado ? `
      <div class="lock-banner">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
        Esta avaliação já foi enviada e está travada para edição. Apenas o administrador pode liberar uma nova edição.
      </div>` : ''}
    ${liberado ? `
      <div class="alert alert-info" style="display:flex; align-items:center; gap:8px">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:16px;flex-shrink:0"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        Edição liberada pelo administrador. Revise as respostas e reenvie o formulário.
      </div>` : ''}
    <div id="form-fill-wrap"></div>
  `;

  // Se liberado, passa como existente para pré-preencher mas travado=false para editar
  renderFormFill(form, fornecedor, assoc, existente, travado, chaveMes);
}

function renderFormFill(form, fornecedor, assoc, existente, travado, chaveMes) {
  const respostasIniciais = existente ? existente.respostas : {};
  window._formAtual = { form, fornecedor, assoc, existente, chaveMes, respostas: JSON.parse(JSON.stringify(respostasIniciais)), anexos: existente ? (existente.anexos || []) : [] };

  const wrap = document.getElementById('form-fill-wrap');

  // Campos institucionais do formulário
  const camposLinha = (form.camposExtras && form.camposExtras.length)
    ? form.camposExtras.filter(c => c.valor).map(c => `<span><b style="font-weight:600">${c.label}:</b> ${c.valor}</span>`).join(' &nbsp;·&nbsp; ')
    : '';

  wrap.innerHTML = `
    <div class="card">
      ${camposLinha ? `<div style="padding:10px 14px; background:var(--surface2); border-radius:8px; margin-bottom:14px; font-size:12px; color:var(--text-sec); display:flex; flex-wrap:wrap; gap:12px">${camposLinha}</div>` : ''}
      ${form.criterios.map(crit => {
        const resp = respostasIniciais[crit.id];
        return `
        <div class="criterio-block">
          <div class="criterio-header">
            <span class="criterio-nome">${crit.nome}</span>
            <span class="criterio-peso">até ${crit.pesoMax.toFixed(1)}P</span>
          </div>
          ${crit.opcoes.map((op, i) => `
            <label class="opcao-row ${resp && resp.opcaoIndex === i && !resp.naoHouve ? 'selected' : ''}" onclick="selecionarOpcao('${crit.id}', ${i}, this)">
              <input type="radio" name="crit-${crit.id}" ${resp && resp.opcaoIndex === i && !resp.naoHouve ? 'checked' : ''} ${travado ? 'disabled' : ''}>
              <span class="opcao-label">${op.label}</span>
              <span class="opcao-pontos">${op.pontos.toFixed(1)}P</span>
            </label>
          `).join('')}
          <label class="opcao-row ${resp && resp.naoHouve ? 'selected' : ''}" onclick="selecionarNaoHouve('${crit.id}', this)" style="margin-top:4px; border-top:1px dashed var(--border); padding-top:10px">
            <input type="radio" name="crit-${crit.id}" ${resp && resp.naoHouve ? 'checked' : ''} ${travado ? 'disabled' : ''}>
            <span class="opcao-label" style="color:var(--text-muted)">Não houve serviço no mês avaliado</span>
            <span class="opcao-pontos" style="color:var(--text-muted)">desconsiderado</span>
          </label>
        </div>`;
      }).join('')}

      <div class="nota-preview">
        <span class="nota-preview-label">Nota calculada</span>
        <span class="nota-preview-value" id="nota-preview-val">${existente && existente.nota !== null ? existente.nota.toFixed(1) : '—'}</span>
      </div>

      <div id="justificativa-wrap"></div>

      <div class="form-group" style="margin-top:14px">
        <label>Anexar evidências (PDF, foto, relatório)</label>
        <div class="file-drop" onclick="document.getElementById('anexo-input').click()">
          <input type="file" id="anexo-input" multiple onchange="handleAnexo(event)" ${travado ? 'disabled' : ''}>
          <p style="font-size:12px; color:var(--text-muted)">Clique para selecionar arquivos</p>
        </div>
        <div id="anexos-lista"></div>
      </div>

      <div class="form-group" style="margin-top:14px">
        <label>Observação (opcional)</label>
        <textarea id="obs-formulario" rows="2" ${travado ? 'disabled' : ''}>${existente ? (existente.obs || '') : ''}</textarea>
      </div>

      ${!travado ? `
        <div style="display:flex; justify-content:flex-end; margin-top:18px; gap:10px">
          <button class="btn btn-primary" onclick="enviarAvaliacao()">${existente ? 'Reenviar avaliação' : 'Enviar avaliação'}</button>
        </div>
      ` : `
        <div style="display:flex; justify-content:flex-end; margin-top:18px">
          <button class="btn btn-secondary" onclick="solicitarLiberacao()">Solicitar liberação ao admin</button>
        </div>
      `}
    </div>
  `;
  renderAnexosLista();
  updateNotaPreview();
}

function selecionarOpcao(critId, idx, el) {
  if (!window._formAtual) return;
  window._formAtual.respostas[critId] = { opcaoIndex: idx, naoHouve: false };
  el.parentElement.querySelectorAll('.opcao-row').forEach(r => r.classList.remove('selected'));
  el.classList.add('selected');
  updateNotaPreview();
}

function selecionarNaoHouve(critId, el) {
  if (!window._formAtual) return;
  window._formAtual.respostas[critId] = { opcaoIndex: null, naoHouve: true };
  el.parentElement.querySelectorAll('.opcao-row').forEach(r => r.classList.remove('selected'));
  el.classList.add('selected');
  updateNotaPreview();
}

function updateNotaPreview() {
  const { form, respostas } = window._formAtual;
  const result = calcularNota(form, respostas);
  const el = document.getElementById('nota-preview-val');
  el.textContent = result.semServico ? 'Sem serviço' : (result.nota !== null ? result.nota.toFixed(1) : '—');

  const justWrap = document.getElementById('justificativa-wrap');
  const sit = result.semServico ? null : getSituacao(result.nota);
  if (sit === 'reprovado') {
    justWrap.innerHTML = `
      <div class="form-group" style="margin-top:14px">
        <label style="color:var(--danger)">Melhoria esperada (obrigatório para reprovados)</label>
        <textarea id="justificativa-reprovacao" rows="3" placeholder="O que o fornecedor precisa melhorar para atingir uma nota melhor na próxima avaliação..." style="border-color:var(--danger-border)">${window._formAtual.existente && window._formAtual.existente.justificativa ? window._formAtual.existente.justificativa : ''}</textarea>
      </div>`;
  } else {
    justWrap.innerHTML = '';
  }
}

function handleAnexo(e) {
  const files = Array.from(e.target.files);
  files.forEach(f => {
    window._formAtual.anexos.push({ nome: f.name, tamanho: (f.size / 1024).toFixed(0) + ' KB' });
  });
  renderAnexosLista();
  e.target.value = '';
}

function renderAnexosLista() {
  const wrap = document.getElementById('anexos-lista');
  if (!wrap) return;
  wrap.innerHTML = window._formAtual.anexos.map((a, i) => `
    <div class="anexo-item">
      <span>📎 ${a.nome}</span><span style="color:var(--text-muted)">${a.tamanho}</span>
      <button onclick="removerAnexo(${i})">remover</button>
    </div>`).join('');
}

function removerAnexo(i) {
  window._formAtual.anexos.splice(i, 1);
  renderAnexosLista();
}

async function enviarAvaliacao() {
  const { form, fornecedor, assoc, existente, chaveMes, respostas, anexos } = window._formAtual;
  const totalCriterios = form.criterios.length;
  const respondidos = Object.keys(respostas).filter(k => respostas[k]).length;

  if (respondidos < totalCriterios) {
    toast('Preencha todos os critérios antes de enviar.');
    return;
  }

  const result = calcularNota(form, respostas);
  const sit = result.semServico ? null : getSituacao(result.nota);

  if (sit === 'reprovado') {
    const just = document.getElementById('justificativa-reprovacao').value.trim();
    if (!just) {
      toast('Indique a melhoria esperada para fornecedores reprovados.');
      return;
    }
  }

  const justificativa = sit === 'reprovado' ? document.getElementById('justificativa-reprovacao').value.trim() : '';
  const obs = document.getElementById('obs-formulario').value.trim();

  const payload = {
    formulario_id: form.id,
    fornecedor_id: assoc.fornecedorId,
    usuario_id: currentUser.id,
    periodo: chaveMes,
    respostas,
    nota_media: result.semServico ? null : result.nota,
    sem_servico: result.semServico,
    situacao: sit,
    anexos,
    obs,
    justificativa,
    enviado_em: new Date().toISOString(),
    enviado_por_email: currentUser.email,
    bloqueada: true,
    liberado_edicao: false,
  };

  // Só REESCREVE a mesma avaliação se ela existia E o admin liberou a edição
  // (correção de um envio). Qualquer outro caso — inclusive "avaliar outro
  // atendimento" com um envio já travado no mês — cria uma linha NOVA, que
  // entra na média junto com as demais do período.
  let error;
  if (existente && existente.liberadoEdicao) {
    ({ error } = await supabaseClient.from('avaliacoes').update(payload).eq('id', existente.id));
  } else {
    ({ error } = await supabaseClient.from('avaliacoes').insert({ ...payload, empresa_id: currentUser.empresaId }));
  }

  if (error) { toast('Erro ao enviar avaliação: ' + error.message); return; }

  addLog('avaliacao_enviada', `${currentUser.email} enviou avaliação do formulário "${form.nome}" (${MESES[parseInt(chaveMes.split('-')[1])]}/${chaveMes.split('-')[0]}) — nota: ${result.semServico ? 'sem serviço' : result.nota.toFixed(1)}`);

  toast('Avaliação enviada e travada para edição!');
  await carregarAvaliacoes();
  renderAvFormularios();
}

function solicitarLiberacao() {
  addLog('solicitacao_liberacao', `${currentUser.email} solicitou liberação de edição para reabrir uma avaliação travada`);
  toast('Solicitação registrada. Avise o administrador para liberar a edição.');
}

function renderAvHistorico() {
  const d = db();
  const anoSel = document.getElementById('hist-filtro-ano');
  const mesSel = document.getElementById('hist-filtro-mes');
  const anoFiltro = anoSel ? anoSel.value : '';
  const mesFiltro = mesSel ? mesSel.value : '';

  const todasMinhas = d.avaliacoes.filter(av => av.usuarioId === currentUser.id);
  const anosDisponiveis = [...new Set(todasMinhas.map(av => av.periodo.split('-')[0]))].sort().reverse();

  let minhasAvaliacoes = todasMinhas;
  if (anoFiltro) minhasAvaliacoes = minhasAvaliacoes.filter(av => av.periodo.split('-')[0] === anoFiltro);
  if (mesFiltro) minhasAvaliacoes = minhasAvaliacoes.filter(av => av.periodo.split('-')[1] === mesFiltro);
  minhasAvaliacoes = minhasAvaliacoes.sort((a,b) => new Date(b.enviadoEm) - new Date(a.enviadoEm));

  const wrap = document.getElementById('av-page-historico');

  wrap.innerHTML = `
    <div class="page-header"><div><h2>Histórico de envios</h2><p>Todas as avaliações que você enviou</p></div></div>
    <div class="card" style="margin-bottom:14px">
      <div style="display:flex; gap:10px; flex-wrap:wrap">
        <div class="form-group" style="margin:0; min-width:120px">
          <label>Ano</label>
          <select id="hist-filtro-ano" onchange="renderAvHistorico()">
            <option value="">Todos</option>
            ${anosDisponiveis.map(a => `<option value="${a}" ${a === anoFiltro ? 'selected' : ''}>${a}</option>`).join('')}
          </select>
        </div>
        <div class="form-group" style="margin:0; min-width:150px">
          <label>Mês</label>
          <select id="hist-filtro-mes" onchange="renderAvHistorico()">
            <option value="">Todos</option>
            ${MESES.map((m, i) => i > 0 ? `<option value="${i}" ${String(i) === mesFiltro ? 'selected' : ''}>${m}</option>` : '').join('')}
          </select>
        </div>
      </div>
    </div>
    <div class="card">
      ${!minhasAvaliacoes.length ? '<div class="empty-state"><p>Nenhuma avaliação encontrada para esse período.</p></div>' : `
      <table>
        <thead><tr><th>Formulário</th><th>Período</th><th style="text-align:center">Nota</th><th>Situação</th><th>Enviado em</th></tr></thead>
        <tbody>
          ${minhasAvaliacoes.map(av => {
            const form = d.formularios.find(f => f.id === av.formularioId);
            const [ano, mes] = av.periodo.split('-');
            const sit = av.semServico ? null : getSituacao(av.nota);
            return `<tr style="cursor:pointer" onclick="verDetalheAvaliacao('${av.id}')">
              <td style="font-weight:500">${form ? form.nome : '—'}</td>
              <td>${MESES[parseInt(mes)]}/${ano}</td>
              <td style="text-align:center; font-weight:600">${av.semServico ? '—' : av.nota.toFixed(1)}</td>
              <td>${av.semServico ? '<span class="badge badge-neutral">Sem serviço</span>' : badgeSit(sit)}</td>
              <td style="color:var(--text-muted)">${fmtData(av.enviadoEm)}</td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>`}
    </div>
  `;
}

// ============ SHELL DO ADMIN ============
function renderAdminShell() {
  document.getElementById('sidebar').innerHTML = `
    <div class="sidebar-logo"><h1>AvaliaPro</h1><p>Gestão da Qualidade</p></div>
    <div class="sidebar-user">
      <div class="sidebar-user-avatar">${currentUser.nome.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase()}</div>
      <div class="sidebar-user-info">
        <p>${currentUser.nome}</p>
        <span>${currentUser.email}</span><br>
        <span class="role-badge admin">Admin</span>
      </div>
    </div>
    <button class="nav-item active" onclick="showAdPage('dashboard', this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
      Dashboard
    </button>
    <button class="nav-item" onclick="showAdPage('fornecedores', this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
      Fornecedores
    </button>
    <button class="nav-item" onclick="showAdPage('formularios', this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
      Formulários
    </button>
    <button class="nav-item" onclick="showAdPage('usuarios', this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M4 21v-1a8 8 0 0 1 16 0v1"/></svg>
      Usuários e acessos
    </button>
    <button class="nav-item" onclick="showAdPage('avaliacoes', this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
      Avaliações recebidas
    </button>
    <button class="nav-item" onclick="showAdPage('relatorio', this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
      Relatório & PDFs
    </button>
    <div class="nav-sep"></div>
    <button class="nav-item" onclick="showAdPage('config', this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M4.93 19.07A10 10 0 0 1 4.93 4.93"/></svg>
      Configurações
    </button>
    <button class="nav-item" onclick="showAdPage('auditoria', this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
      Log de auditoria
    </button>
    <div class="nav-logout">
      <button class="nav-item" onclick="doLogout()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
        Sair
      </button>
    </div>
  `;
  document.getElementById('main').innerHTML = `
    <div class="page active" id="ad-page-dashboard"></div>
    <div class="page" id="ad-page-fornecedores"></div>
    <div class="page" id="ad-page-formularios"></div>
    <div class="page" id="ad-page-usuarios"></div>
    <div class="page" id="ad-page-avaliacoes"></div>
    <div class="page" id="ad-page-relatorio"></div>
    <div class="page" id="ad-page-config"></div>
    <div class="page" id="ad-page-auditoria"></div>
  `;
  renderAdDashboard();
}

function showAdPage(page, btn) {
  document.querySelectorAll('#sidebar .nav-item').forEach(n => n.classList.remove('active'));
  if (btn) btn.classList.add('active');
  document.querySelectorAll('#main .page').forEach(p => p.classList.remove('active'));
  document.getElementById('ad-page-' + page).classList.add('active');
  const renderers = {
    dashboard: renderAdDashboard, fornecedores: renderAdFornecedores, formularios: renderAdFormularios,
    usuarios: renderAdUsuarios, avaliacoes: renderAdAvaliacoes, relatorio: renderAdRelatorio,
    config: renderAdConfig, auditoria: renderAdAuditoria
  };
  if (renderers[page]) renderers[page]();
}

// ---------- DASHBOARD ----------
function renderAdDashboard() {
  const d = db();
  const mesAtual = new Date().getMonth() + 1;
  const anoAtual = new Date().getFullYear();
  const chaveMes = `${anoAtual}-${mesAtual}`;

  const totalFormPendentes = d.associacoes.length;
  const enviadosMes = d.avaliacoes.filter(av => av.periodo === chaveMes).length;
  const pendentesMes = totalFormPendentes - enviadosMes;
  const reprovadosLista = d.avaliacoes.filter(av => av.periodo === chaveMes && !av.semServico && (getSituacao(av.nota) === 'reprovado' || getSituacao(av.nota) === 'parcial'));
  const reprovadosMes = reprovadosLista.filter(av => getSituacao(av.nota) === 'reprovado').length;

  let alertaNotificar = '';
  if (reprovadosLista.length) {
    alertaNotificar = `
      <div class="card" style="border-left: 3px solid var(--danger); margin-bottom:16px">
        <div class="card-title" style="color:var(--danger)">
          📩 Fornecedores para notificar (Parcial/Reprovado — ${MESES[mesAtual]})
        </div>
        ${reprovadosLista.map(av => {
          const forn = d.fornecedores.find(f => f.id === av.fornecedorId);
          const sit = getSituacao(av.nota);
          return `<div style="display:flex; align-items:center; gap:8px; padding:6px 0; border-bottom:1px solid var(--border); font-size:12px">
            <span><b>${forn ? forn.nome : '—'}</b> — nota ${av.nota.toFixed(1)}</span>
            ${badgeSit(sit)}
          <button class="btn btn-secondary btn-sm" style="margin-left:auto" onclick="abrirNotificacaoAvaliacao('${av.id}')">🔔 Ver / Notificar</button>
          </div>`;
        }).join('')}
      </div>`;
  }

  const { vencidos, proximos } = contarDocumentosVencendo(d);

  let alertasDoc = '';
  if (vencidos.length || proximos.length) {
    const linhasVencidos = vencidos.map(doc => {
      const forn = d.fornecedores.find(f => f.id === doc.fornecedorId);
      return `<div style="display:flex; align-items:center; gap:8px; padding:5px 0; border-bottom:1px solid rgba(220,38,38,0.15); font-size:12px">
        <span style="color:var(--danger); font-weight:600">VENCIDO</span>
        <span><b>${forn ? forn.nome : '—'}</b> — ${doc.nome}</span>
        <span style="color:var(--text-muted); margin-left:auto">válido até ${new Date(doc.validade+'T00:00:00').toLocaleDateString('pt-BR')}</span>
      </div>`;
    }).join('');
    const linhasProximos = proximos.map(doc => {
      const forn = d.fornecedores.find(f => f.id === doc.fornecedorId);
      const dias = diasParaVencer(doc.validade);
      return `<div style="display:flex; align-items:center; gap:8px; padding:5px 0; border-bottom:1px solid rgba(217,119,6,0.15); font-size:12px">
        <span style="color:var(--warn); font-weight:600">VENCE EM ${dias}D</span>
        <span><b>${forn ? forn.nome : '—'}</b> — ${doc.nome}</span>
        <span style="color:var(--text-muted); margin-left:auto">${new Date(doc.validade+'T00:00:00').toLocaleDateString('pt-BR')}</span>
      </div>`;
    }).join('');

    alertasDoc = `
      <div class="card" style="border-left: 3px solid var(--danger); margin-bottom:16px">
        <div class="card-title" style="color:var(--danger)">
          ⚠️ Documentos de fornecedores que precisam de atenção
          <span style="font-size:11px; font-weight:400; color:var(--text-muted)">${vencidos.length + proximos.length} ocorrência(s)</span>
        </div>
        ${linhasVencidos}${linhasProximos}
        <div style="margin-top:10px">
          <button class="btn btn-secondary btn-sm" onclick="showAdPage('fornecedores', document.querySelectorAll('#sidebar .nav-item')[1])">Ver fornecedores →</button>
        </div>
      </div>`;
  }

  document.getElementById('ad-page-dashboard').innerHTML = `
    <div class="page-header"><div><h2>Dashboard</h2><p>${MESES[mesAtual]} de ${anoAtual}</p></div></div>
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-label">Fornecedores</div><div class="stat-value">${d.fornecedores.length}</div><div class="stat-sub">cadastrados</div></div>
      <div class="stat-card"><div class="stat-label">Avaliações enviadas</div><div class="stat-value" style="color:var(--success)">${enviadosMes}</div><div class="stat-sub">no mês atual</div></div>
      <div class="stat-card"><div class="stat-label">Pendentes</div><div class="stat-value" style="color:var(--warn)">${Math.max(0, pendentesMes)}</div><div class="stat-sub">aguardando setor</div></div>
      <div class="stat-card"><div class="stat-label">Reprovados</div><div class="stat-value" style="color:var(--danger)">${reprovadosMes}</div><div class="stat-sub">no mês atual</div></div>
    </div>
    ${alertaNotificar}
    ${alertasDoc}
    <div class="card">
      <div class="card-title">Avaliações recentes</div>
      ${renderAvaliacoesTable(d.avaliacoes.slice().sort((a,b) => new Date(b.enviadoEm) - new Date(a.enviadoEm)).slice(0,8), d)}
    </div>
  `;
}

function renderAvaliacoesTable(lista, d) {
  if (!lista.length) return '<div class="empty-state"><p>Nenhuma avaliação registrada ainda.</p></div>';
  return `<table>
    <thead><tr><th>Formulário</th><th>Fornecedor</th><th>Enviado por</th><th style="text-align:center">Nota</th><th>Situação</th><th>Data</th></tr></thead>
    <tbody>
      ${lista.map(av => {
        const form = d.formularios.find(f => f.id === av.formularioId);
        const forn = d.fornecedores.find(f => f.id === av.fornecedorId);
        const sit = av.semServico ? null : getSituacao(av.nota);
        return `<tr>
          <td style="font-weight:500">${form ? form.nome : '—'}</td>
          <td>${forn ? forn.nome : '—'}</td>
          <td style="color:var(--text-sec)">${av.enviadoPor}</td>
          <td style="text-align:center; font-weight:600">${av.semServico ? '—' : av.nota.toFixed(1)}</td>
          <td>${av.semServico ? '<span class="badge badge-neutral">Sem serviço</span>' : badgeSit(sit)}</td>
          <td style="color:var(--text-muted); font-size:11px">${fmtData(av.enviadoEm)}</td>
        </tr>`;
      }).join('')}
    </tbody>
  </table>`;
}

// ---------- FORNECEDORES ----------
function campoCustomInputHTML(campo, prefix, valor) {
  const id = `${prefix}${campo.chave}`;
  const v = (valor !== undefined && valor !== null) ? valor : '';
  if (campo.tipo === 'select') {
    const opcoes = campo.opcoes || [];
    return `<div class="form-group"><label>${campo.label}</label><select id="${id}"><option value="">—</option>${opcoes.map(o => `<option value="${o}" ${o === v ? 'selected' : ''}>${o}</option>`).join('')}</select></div>`;
  }
  if (campo.tipo === 'data') {
    return `<div class="form-group"><label>${campo.label}</label><input type="date" id="${id}" value="${v}"></div>`;
  }
  return `<div class="form-group"><label>${campo.label}</label><input type="text" id="${id}" value="${v}"></div>`;
}

let _abaFornecedoresAtual = 'ativos';
let _filtroFornecedores = { busca: '', tipo: '', setor: '', criticidade: '' };

function renderAdFornecedores() {
  const d = db();
  const vencendoCount = contarDocumentosVencendo(d);
  const ativos = d.fornecedores.filter(f => f.ativo !== false);
  const desativados = d.fornecedores.filter(f => f.ativo === false);
  const setoresUnicos = [...new Set(d.fornecedores.map(f => f.setor).filter(Boolean))].sort();

  document.getElementById('ad-page-fornecedores').innerHTML = `
    <div class="page-header"><div><h2>Fornecedores</h2><p>Cadastro de fornecedores e arquivo de documentações (alvará, contratos, certidões etc)</p></div></div>
    ${vencendoCount.vencidos.length || vencendoCount.proximos.length ? `
      <div class="alert ${vencendoCount.vencidos.length ? 'alert-danger' : 'alert-warn'}">
        ${vencendoCount.vencidos.length ? `<b>${vencendoCount.vencidos.length} documento(s) vencido(s)</b>` : ''}
        ${vencendoCount.vencidos.length && vencendoCount.proximos.length ? ' · ' : ''}
        ${vencendoCount.proximos.length ? `<b>${vencendoCount.proximos.length} documento(s) vencendo nos próximos 10 dias</b>` : ''}
        — verifique abaixo nos respectivos fornecedores.
      </div>` : ''}
    <div class="card">
      <div class="card-title">Novo fornecedor</div>
      <div class="form-row three">
        <div class="form-group"><label>Nome</label><input type="text" id="nf-nome" placeholder="Nome do fornecedor"></div>
        <div class="form-group"><label>Tipo</label><select id="nf-tipo"><option value="servico">Serviço</option><option value="produto">Produto</option></select></div>
        <div class="form-group"><label>Setor</label><input type="text" id="nf-setor" placeholder="Ex: Qualidade"></div>
      </div>
      <div class="form-row" style="grid-template-columns:1fr 1fr 1fr 1fr">
        <div class="form-group"><label>E-mail</label><input type="email" id="nf-email" placeholder="contato@fornecedor.com"></div>
        <div class="form-group"><label>Telefone</label><input type="text" id="nf-telefone" placeholder="(00) 00000-0000" oninput="this.value = formatarTelefone(this.value)"></div>
        <div class="form-group"><label>CNPJ</label><input type="text" id="nf-cnpj" placeholder="00.000.000/0000-00" oninput="this.value = formatarCNPJ(this.value)"></div>
        <div class="form-group"><label>Criticidade</label>
          <select id="nf-criticidade">
            <option value="baixa">Baixa</option>
            <option value="media" selected>Média</option>
            <option value="alta">Alta</option>
          </select>
        </div>
      </div>
      ${d.camposFornecedorCustom.length ? `<div class="form-row three">${d.camposFornecedorCustom.map(c => campoCustomInputHTML(c, 'nf-extra-')).join('')}</div>` : ''}
      <button class="btn btn-primary" onclick="addFornecedorAd()">Adicionar fornecedor</button>
      <p style="font-size:11px; color:var(--text-muted); margin-top:8px">Quer adicionar outros campos (contrato, contato, categoria etc)? Vá em <b>Configurações › Campos do fornecedor</b>.</p>
    </div>
    <div class="card">
      <div class="tab-bar" style="margin-bottom:0">
        <button class="tab ${_abaFornecedoresAtual === 'ativos' ? 'active' : ''}" onclick="mudarAbaFornecedores('ativos')">Ativos (${ativos.length})</button>
        <button class="tab ${_abaFornecedoresAtual === 'desativados' ? 'active' : ''}" onclick="mudarAbaFornecedores('desativados')">Desativados (${desativados.length})</button>
      </div>
      <div style="display:flex; gap:10px; flex-wrap:wrap; align-items:flex-end; margin:16px 0">
        <div class="form-group" style="min-width:180px; flex:1"><label>Buscar (nome ou e-mail)</label><input type="text" id="ff-busca" value="${_filtroFornecedores.busca}" oninput="aplicarFiltroFornecedores()" placeholder="Digite para buscar..."></div>
        <div class="form-group" style="min-width:130px"><label>Tipo</label><select id="ff-tipo" onchange="aplicarFiltroFornecedores()"><option value="">Todos</option><option value="servico" ${_filtroFornecedores.tipo === 'servico' ? 'selected' : ''}>Serviço</option><option value="produto" ${_filtroFornecedores.tipo === 'produto' ? 'selected' : ''}>Produto</option></select></div>
        <div class="form-group" style="min-width:150px"><label>Setor/Categoria</label><select id="ff-setor" onchange="aplicarFiltroFornecedores()"><option value="">Todos</option>${setoresUnicos.map(s => `<option value="${s}" ${_filtroFornecedores.setor === s ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
        <div class="form-group" style="min-width:130px"><label>Criticidade</label><select id="ff-criticidade" onchange="aplicarFiltroFornecedores()"><option value="">Todas</option><option value="alta" ${_filtroFornecedores.criticidade === 'alta' ? 'selected' : ''}>Alta</option><option value="media" ${_filtroFornecedores.criticidade === 'media' ? 'selected' : ''}>Média</option><option value="baixa" ${_filtroFornecedores.criticidade === 'baixa' ? 'selected' : ''}>Baixa</option></select></div>
        <button class="sup-toolbar-btn" onclick="abrirColunasVisiveisFornecedor()">⚙️ Colunas visíveis</button>
      </div>
      <div id="fornecedores-lista-ad"></div>
    </div>
  `;
  renderFornecedoresListaAd();
}

function mudarAbaFornecedores(aba) {
  _abaFornecedoresAtual = aba;
  renderAdFornecedores();
}

function aplicarFiltroFornecedores() {
  _filtroFornecedores.busca = document.getElementById('ff-busca').value.trim().toLowerCase();
  _filtroFornecedores.tipo = document.getElementById('ff-tipo').value;
  _filtroFornecedores.setor = document.getElementById('ff-setor').value;
  _filtroFornecedores.criticidade = document.getElementById('ff-criticidade').value;
  renderFornecedoresListaAd();
}

function diasParaVencer(dataISO) {
  const hoje = new Date(); hoje.setHours(0,0,0,0);
  const venc = new Date(dataISO + 'T00:00:00');
  return Math.ceil((venc - hoje) / (1000*60*60*24));
}

function contarDocumentosVencendo(d) {
  const vencidos = [], proximos = [];
  d.documentos.forEach(doc => {
    const dias = diasParaVencer(doc.validade);
    if (dias < 0) vencidos.push(doc);
    else if (dias <= 10) proximos.push(doc);
  });
  return { vencidos, proximos };
}

function statusDocumento(dataISO) {
  const dias = diasParaVencer(dataISO);
  if (dias < 0) return { cls: 'badge-danger', label: `Vencido há ${Math.abs(dias)}d` };
  if (dias <= 10) return { cls: 'badge-warn', label: `Vence em ${dias}d` };
  return { cls: 'badge-success', label: 'Em dia' };
}

const COLUNAS_FORNECEDOR_BASE = [
  { chave: 'tipo', label: 'Tipo' },
  { chave: 'setor', label: 'Setor' },
  { chave: 'criticidade', label: 'Criticidade' },
  { chave: 'email', label: 'E-mail' },
  { chave: 'telefone', label: 'Telefone' },
  { chave: 'cnpj', label: 'CNPJ' },
  { chave: 'documentos', label: 'Resumo de documentos' }
];

function badgeHTML(texto, classe) {
  return `<span class="sup-badge ${classe || ''}">${texto}</span>`;
}

function formatarCNPJ(valor) {
  let v = (valor || '').replace(/\D/g, '').slice(0, 14);
  if (v.length > 12) v = v.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{1,2}).*/, '$1.$2.$3/$4-$5');
  else if (v.length > 8) v = v.replace(/^(\d{2})(\d{3})(\d{3})(\d{1,4}).*/, '$1.$2.$3/$4');
  else if (v.length > 5) v = v.replace(/^(\d{2})(\d{3})(\d{1,3}).*/, '$1.$2.$3');
  else if (v.length > 2) v = v.replace(/^(\d{2})(\d{1,3}).*/, '$1.$2');
  return v;
}

function formatarTelefone(valor) {
  let v = (valor || '').replace(/\D/g, '').slice(0, 11);
  if (v.length > 10) v = v.replace(/^(\d{2})(\d{5})(\d{1,4}).*/, '($1) $2-$3');
  else if (v.length > 6) v = v.replace(/^(\d{2})(\d{4})(\d{1,4}).*/, '($1) $2-$3');
  else if (v.length > 2) v = v.replace(/^(\d{2})(\d{1,4}).*/, '($1) $2');
  else if (v.length > 0) v = v.replace(/^(\d{1,2}).*/, '($1');
  return v;
}

function metaItemHTML(icone, texto, mono) {
  return `<span class="sup-meta-item${mono ? ' mono' : ''}"><span class="ic">${icone}</span>${texto}</span>`;
}

function pluralDocs(n) {
  if (n === 0) return 'sem documentos';
  if (n === 1) return '1 documento';
  return `${n} documentos`;
}

function abrirColunasVisiveisFornecedor() {
  const d = db();
  const todas = [...COLUNAS_FORNECEDOR_BASE, ...d.camposFornecedorCustom.map(c => ({ chave: 'extra_' + c.chave, label: c.label }))];
  const vis = d.colunasFornecedorVisiveis;
  openModal(`
    <h3>Colunas visíveis na listagem</h3>
    <p style="font-size:12px; color:var(--text-muted); margin-bottom:14px">Escolha quais informações aparecem em cada fornecedor.</p>
    <div style="display:flex; flex-direction:column; gap:4px; max-height:320px; overflow-y:auto">
      ${todas.map(c => `<label class="checklist-item"><input type="checkbox" value="${c.chave}" ${vis.includes(c.chave) ? 'checked' : ''}> ${c.label}</label>`).join('')}
    </div>
    <div style="display:flex; gap:8px; margin-top:18px">
      <button class="btn btn-primary btn-block" onclick="salvarColunasVisiveisFornecedor()">Salvar</button>
      <button class="btn btn-secondary" onclick="closeModal()">Cancelar</button>
    </div>
  `);
}

async function salvarColunasVisiveisFornecedor() {
  const checks = document.querySelectorAll('#modal-box input[type=checkbox]:checked');
  const vis = Array.from(checks).map(c => c.value);

  const { error } = await supabaseClient
    .from('empresas')
    .update({ colunas_fornecedor_visiveis: vis })
    .eq('id', currentUser.empresaId);

  if (error) { toast('Erro ao salvar colunas: ' + error.message); return; }

  empresaConfigCache.colunas_fornecedor_visiveis = vis;
  addLog('colunas_fornecedor_atualizadas', `${currentUser.email} alterou as colunas visíveis da listagem de fornecedores`);
  closeModal();
  renderFornecedoresListaAd();
  toast('Colunas atualizadas!');
}

function renderFornecedoresListaAd() {
  const d = db();
  const wrap = document.getElementById('fornecedores-lista-ad');
  const aba = _abaFornecedoresAtual;
  let lista = d.fornecedores.filter(f => aba === 'ativos' ? f.ativo !== false : f.ativo === false);

  const filtro = _filtroFornecedores;
  if (filtro.busca) lista = lista.filter(f => (f.nome || '').toLowerCase().includes(filtro.busca) || (f.email || '').toLowerCase().includes(filtro.busca));
  if (filtro.tipo) lista = lista.filter(f => f.tipo === filtro.tipo);
  if (filtro.setor) lista = lista.filter(f => f.setor === filtro.setor);
  if (filtro.criticidade) lista = lista.filter(f => (f.criticidade || 'media') === filtro.criticidade);

  if (!lista.length) {
    wrap.innerHTML = `<div class="empty-state"><p>${aba === 'ativos' ? 'Nenhum fornecedor encontrado com esses filtros.' : 'Nenhum fornecedor desativado.'}</p></div>`;
    return;
  }

  const colVis = d.colunasFornecedorVisiveis;

  wrap.innerHTML = lista.map(f => {
    const docs = d.documentos.filter(doc => doc.fornecedorId === f.id);
    const piorStatus = docs.reduce((acc, doc) => {
      const dias = diasParaVencer(doc.validade);
      if (dias < 0) return 'vencido';
      if (dias <= 10 && acc !== 'vencido') return 'proximo';
      return acc;
    }, 'ok');
    const dotCor = piorStatus === 'vencido' ? 'var(--danger)' : piorStatus === 'proximo' ? 'var(--warn)' : 'var(--success)';

    // Badges de status (linha do nome)
    const badges = [];
    if (colVis.includes('criticidade')) {
      const crit = f.criticidade || 'media';
      const classe = crit === 'alta' ? 'sup-badge-crit-alta' : crit === 'baixa' ? 'sup-badge-crit-baixa' : 'sup-badge-crit-media';
      const txt = crit === 'alta' ? 'Crítico' : crit === 'baixa' ? 'Não crítico' : 'Média criticidade';
      badges.push(badgeHTML(txt, classe));
    }
    if (colVis.includes('tipo')) badges.push(badgeHTML(f.tipo === 'produto' ? 'Produto' : 'Serviço', f.tipo === 'produto' ? 'sup-badge-tipo-produto' : 'sup-badge-tipo-servico'));

    // Metadados em texto simples, separados por "|" (linha de baixo)
    const meta = [];
    if (colVis.includes('email') && f.email) meta.push(metaItemHTML('✉️', f.email));
    if (colVis.includes('telefone') && f.telefone) meta.push(metaItemHTML('📞', f.telefone));
    if (colVis.includes('cnpj') && f.cnpj) meta.push(metaItemHTML('🏢', f.cnpj, true));
    if (colVis.includes('setor') && f.setor) meta.push(metaItemHTML('📌', f.setor));
    d.camposFornecedorCustom.forEach(c => {
      const v = (f.extras || {})[c.chave];
      if (colVis.includes('extra_' + c.chave) && v) meta.push(metaItemHTML('•', `${c.label}: ${v}`));
    });
    if (colVis.includes('documentos')) {
      const classeDoc = piorStatus === 'vencido' ? 'sup-badge-doc-danger' : piorStatus === 'proximo' ? 'sup-badge-doc-warn' : docs.length ? 'sup-badge-doc-ok' : 'sup-badge-doc-none';
      meta.push(badgeHTML(`📁 ${pluralDocs(docs.length)}`, classeDoc));
    }
    const metaSep = '<span class="sup-meta-sep">|</span>';

    return `
    <div id="fornecedor-row-${f.id}" class="sup-row-wrap ${aba === 'desativados' ? 'inactive' : ''}">
      <div class="sup-row ${aba === 'ativos' ? 'clickable' : ''}" ${aba === 'ativos' ? `onclick="toggleFornecedorDocsList('${f.id}')"` : ''}>
        <div style="display:flex; gap:10px; flex:1; min-width:0">
          <span class="sup-status-dot" style="background:${dotCor}"></span>
          <div style="flex:1; min-width:0">
            <div class="sup-name-line">
              <span class="sup-name">${f.nome}</span>
              ${badges.join('')}
            </div>
            ${meta.length ? `<div class="sup-meta">${meta.join(metaSep)}</div>` : ''}
          </div>
        </div>
        <div class="sup-actions" onclick="event.stopPropagation()">
          ${aba === 'ativos' ? `
            <button class="sup-btn" onclick="abrirEdicaoFornecedor('${f.id}')">✏️ Editar</button>
            <button class="sup-btn" onclick="toggleFornecedorDocsForm('${f.id}')">Documentos ▾</button>
            <button class="sup-btn sup-btn-danger" onclick="desativarFornecedorAd('${f.id}')">Remover</button>
          ` : `
            <button class="sup-btn sup-btn-success" onclick="reativarFornecedorAd('${f.id}')">↺ Reativar</button>
            <button class="sup-btn sup-btn-danger" onclick="excluirFornecedorDefinitivo('${f.id}')">Excluir definitivo</button>
          `}
        </div>
      </div>
      ${aba === 'ativos' ? `
      <div id="docs-wrap-${f.id}" style="display:none; padding:0 10px 16px 27px">
        <div id="doc-form-${f.id}" class="card" style="display:none; margin-bottom:10px; background:var(--surface2)">
          <p style="font-size:12px; font-weight:600; margin-bottom:10px">Novo documento</p>
          <div class="form-row three">
            <div class="form-group">
              <label>Nome do documento</label>
              <input type="text" id="doc-nome-${f.id}" list="doc-tipos-datalist-${f.id}" placeholder="Selecione ou digite...">
              <datalist id="doc-tipos-datalist-${f.id}">${(d.tiposDocumento || []).map(t => `<option value="${t}">`).join('')}</datalist>
            </div>
            <div class="form-group"><label>Validade</label><input type="date" id="doc-validade-${f.id}"></div>
            <div class="form-group"><label>Observação</label><input type="text" id="doc-obs-${f.id}" placeholder="opcional"></div>
          </div>
          <div class="form-group" style="margin-bottom:12px">
            <label style="font-size:12px; font-weight:500; color:var(--text-sec)">Arquivo (PDF ou imagem — opcional)</label>
            <div class="file-drop" onclick="document.getElementById('doc-file-${f.id}').click()" style="padding:10px; cursor:pointer">
              <input type="file" id="doc-file-${f.id}" accept=".pdf,.png,.jpg,.jpeg" style="display:none" onchange="previewDocFile('${f.id}', this)">
              <p id="doc-file-label-${f.id}" style="font-size:12px; color:var(--text-muted)">📎 Clique para selecionar arquivo</p>
            </div>
          </div>
          <button class="btn btn-primary btn-sm" onclick="addDocumento('${f.id}')">Adicionar documento</button>
        </div>
        <div id="docs-lista-${f.id}"></div>
      </div>` : ''}
    </div>`;
  }).join('');

  if (aba === 'ativos') lista.forEach(f => renderDocsLista(f.id));
}

// Clique na linha (fora dos botões): mostra só a lista de documentos já cadastrados
function toggleFornecedorDocsList(id) {
  const el = document.getElementById('docs-wrap-' + id);
  const row = document.getElementById('fornecedor-row-' + id);
  const form = document.getElementById('doc-form-' + id);
  const abrir = el.style.display === 'none';
  el.style.display = abrir ? 'block' : 'none';
  if (form) form.style.display = 'none';
  if (row) row.classList.toggle('expanded', abrir);
}

// Clique no botão "Documentos": abre o painel (se preciso) e mostra/esconde o formulário de cadastro
function toggleFornecedorDocsForm(id) {
  const el = document.getElementById('docs-wrap-' + id);
  const row = document.getElementById('fornecedor-row-' + id);
  const form = document.getElementById('doc-form-' + id);
  const jaAberto = el.style.display !== 'none';
  const formVisivel = form.style.display !== 'none';
  if (jaAberto && formVisivel) {
    form.style.display = 'none';
  } else {
    el.style.display = 'block';
    form.style.display = 'block';
    if (row) row.classList.add('expanded');
  }
}

function previewDocFile(fid, input) {
  const label = document.getElementById('doc-file-label-' + fid);
  if (input.files && input.files[0]) {
    label.textContent = '📎 ' + input.files[0].name;
    label.style.color = 'var(--accent)';
  }
}

function renderDocsLista(fornecedorId) {
  const d = db();
  const wrap = document.getElementById('docs-lista-' + fornecedorId);
  if (!wrap) return;
  const docs = d.documentos.filter(doc => doc.fornecedorId === fornecedorId).sort((a,b) => new Date(a.validade) - new Date(b.validade));
  if (!docs.length) { wrap.innerHTML = '<p style="font-size:12px; color:var(--text-muted)">Nenhum documento arquivado.</p>'; return; }
  wrap.innerHTML = `<table><thead><tr><th>Documento</th><th>Validade</th><th>Status</th><th>Observação</th><th>Arquivo</th><th></th></tr></thead><tbody>
    ${docs.map(doc => {
      const st = statusDocumento(doc.validade);
      const temArquivo = !!doc.arquivo;
      return `<tr>
        <td style="font-weight:500">${doc.nome}</td>
        <td style="color:var(--text-sec)">${new Date(doc.validade + 'T00:00:00').toLocaleDateString('pt-BR')}</td>
        <td><span class="badge ${st.cls}">${st.label}</span></td>
        <td style="color:var(--text-muted); font-size:12px">${doc.obs || '—'}</td>
        <td>${temArquivo ? `<button class="btn btn-secondary btn-sm" onclick="abrirArquivoDoc('${doc.id}')">📄 Abrir</button>` : '<span style="font-size:11px;color:var(--text-muted)">—</span>'}</td>
        <td><div class="actions">
          ${diasParaVencer(doc.validade) < 0 ? `<button class="btn btn-danger btn-sm" onclick="enviarCobrancaDocumento('${doc.id}')" title="Abre seu cliente de e-mail com a cobrança">✉️ Cobrar</button>` : ''}
          <button class="btn btn-danger btn-sm" onclick="removeDocumento('${doc.id}','${fornecedorId}')">Excluir</button>
        </div></td>
      </tr>`;
    }).join('')}
  </tbody></table>`;
}

function abrirArquivoDoc(docId) {
  const d = db();
  const doc = d.documentos.find(x => x.id === docId);
  if (!doc || !doc.arquivo) return;
  const link = document.createElement('a');
  link.href = doc.arquivo;
  link.download = doc.nomeArquivo || doc.nome;
  link.click();
}

function addDocumento(fornecedorId) {
  const nome = document.getElementById(`doc-nome-${fornecedorId}`).value.trim();
  const validade = document.getElementById(`doc-validade-${fornecedorId}`).value;
  const obs = document.getElementById(`doc-obs-${fornecedorId}`).value.trim();
  if (!nome || !validade) { toast('Informe o nome do documento e a validade.'); return; }

  const fileInput = document.getElementById('doc-file-' + fornecedorId);
  const file = fileInput && fileInput.files[0];

  function salvarDocComArquivo(arquivoBase64, nomeArquivo) {
    const validadeFormatada = new Date(validade + 'T00:00:00').toLocaleDateString('pt-BR').replace(/\//g, '-');
    const ext = nomeArquivo ? nomeArquivo.split('.').pop() : '';
    const nomeArquivoFinal = ext ? `${nome}_${validadeFormatada}.${ext}` : '';
    const d = db();
    d.documentos.push({
      id: 'doc' + Date.now(), fornecedorId, nome, validade, obs,
      arquivo: arquivoBase64 || null,
      nomeArquivo: nomeArquivoFinal || null,
      criadoEm: new Date().toISOString()
    });
    save('ap_documentos', d.documentos);
    const forn = d.fornecedores.find(f => f.id === fornecedorId);
    addLog('documento_arquivado', `${currentUser.email} arquivou o documento "${nome}" para o fornecedor "${forn.nome}" (validade: ${validade})`);
    document.getElementById(`doc-nome-${fornecedorId}`).value = '';
    document.getElementById(`doc-validade-${fornecedorId}`).value = '';
    document.getElementById(`doc-obs-${fornecedorId}`).value = '';
    if (fileInput) { fileInput.value = ''; }
    const label = document.getElementById('doc-file-label-' + fornecedorId);
    if (label) { label.textContent = '📎 Clique para selecionar arquivo'; label.style.color = ''; }
    renderDocsLista(fornecedorId);
    renderFornecedoresListaAd();
    document.getElementById('docs-wrap-' + fornecedorId).style.display = 'block';
    const formEl = document.getElementById('doc-form-' + fornecedorId); if (formEl) formEl.style.display = 'block';
    const rowEl = document.getElementById('fornecedor-row-' + fornecedorId); if (rowEl) rowEl.classList.add('expanded');
    toast('Documento arquivado!');
  }

  if (file) {
    const reader = new FileReader();
    reader.onload = e => salvarDocComArquivo(e.target.result, file.name);
    reader.readAsDataURL(file);
  } else {
    salvarDocComArquivo(null, null);
  }
}

function removeDocumento(docId, fornecedorId) {
  if (!confirm('Excluir este documento do arquivo?')) return;
  const d = db();
  const doc = d.documentos.find(x => x.id === docId);
  d.documentos = d.documentos.filter(x => x.id !== docId);
  save('ap_documentos', d.documentos);
  addLog('documento_removido', `${currentUser.email} excluiu o documento "${doc.nome}"`);
  renderDocsLista(fornecedorId);
  renderFornecedoresListaAd();
  document.getElementById('docs-wrap-' + fornecedorId).style.display = 'block';
    const rowEl = document.getElementById('fornecedor-row-' + fornecedorId); if (rowEl) rowEl.classList.add('expanded');
  toast('Documento excluído.');
}

async function addFornecedorAd() {
  const nome = document.getElementById('nf-nome').value.trim();
  const tipo = document.getElementById('nf-tipo').value;
  const setor = document.getElementById('nf-setor').value.trim();
  const email = document.getElementById('nf-email').value.trim();
  const telefone = document.getElementById('nf-telefone').value.trim();
  const cnpj = document.getElementById('nf-cnpj').value.trim();
  const criticidade = document.getElementById('nf-criticidade').value;
  if (!nome) { toast('Informe o nome do fornecedor.'); return; }
  const d = db();
  const extras = {};
  d.camposFornecedorCustom.forEach(c => {
    const el = document.getElementById('nf-extra-' + c.chave);
    if (el) extras[c.chave] = el.value;
  });

  const { error } = await supabaseClient.from('fornecedores').insert({
    empresa_id: currentUser.empresaId,
    nome, tipo, setor, email, telefone, cnpj, criticidade,
    ativo: true, campos_custom: extras,
  });

  if (error) { toast('Erro ao cadastrar fornecedor: ' + error.message); return; }

  addLog('fornecedor_criado', `${currentUser.email} cadastrou o fornecedor "${nome}"`);
  await carregarFornecedores();
  renderAdFornecedores();
  toast('Fornecedor adicionado!');
}

function abrirEdicaoFornecedor(id) {
  const d = db();
  const f = d.fornecedores.find(x => x.id === id);
  if (!f) return;
  openModal(`
    <h3>Editar fornecedor</h3>
    <div class="form-group" style="margin-bottom:10px"><label>Nome</label><input type="text" id="ef-nome" value="${f.nome || ''}"></div>
    <div class="form-row" style="margin-bottom:10px">
      <div class="form-group"><label>Tipo</label><select id="ef-tipo"><option value="servico" ${f.tipo === 'servico' ? 'selected' : ''}>Serviço</option><option value="produto" ${f.tipo === 'produto' ? 'selected' : ''}>Produto</option></select></div>
      <div class="form-group"><label>Setor</label><input type="text" id="ef-setor" value="${f.setor || ''}"></div>
    </div>
    <div class="form-row" style="margin-bottom:10px; grid-template-columns:1fr 1fr 1fr">
      <div class="form-group"><label>E-mail</label><input type="email" id="ef-email" value="${f.email || ''}"></div>
      <div class="form-group"><label>Telefone</label><input type="text" id="ef-telefone" value="${f.telefone || ''}" oninput="this.value = formatarTelefone(this.value)"></div>
      <div class="form-group"><label>CNPJ</label><input type="text" id="ef-cnpj" value="${f.cnpj || ''}" oninput="this.value = formatarCNPJ(this.value)"></div>
    </div>
    <div class="form-group" style="margin-bottom:10px">
      <label>Criticidade</label>
      <select id="ef-criticidade">
        <option value="baixa" ${f.criticidade === 'baixa' ? 'selected' : ''}>Baixa</option>
        <option value="media" ${(!f.criticidade || f.criticidade === 'media') ? 'selected' : ''}>Média</option>
        <option value="alta" ${f.criticidade === 'alta' ? 'selected' : ''}>Alta</option>
      </select>
    </div>
    ${d.camposFornecedorCustom.map(c => `<div style="margin-bottom:10px">${campoCustomInputHTML(c, 'ef-extra-', (f.extras || {})[c.chave])}</div>`).join('')}
    <div style="display:flex; gap:8px; margin-top:16px">
      <button class="btn btn-primary btn-block" onclick="salvarEdicaoFornecedor('${f.id}')">Salvar alterações</button>
      <button class="btn btn-secondary" onclick="closeModal()">Cancelar</button>
    </div>
  `);
}

async function salvarEdicaoFornecedor(id) {
  const d = db();
  const f = d.fornecedores.find(x => x.id === id);
  if (!f) return;
  const nome = document.getElementById('ef-nome').value.trim();
  if (!nome) { toast('Informe o nome do fornecedor.'); return; }
  const extras = f.extras || {};
  d.camposFornecedorCustom.forEach(c => {
    const el = document.getElementById('ef-extra-' + c.chave);
    if (el) extras[c.chave] = el.value;
  });

  const { error } = await supabaseClient.from('fornecedores').update({
    nome,
    tipo: document.getElementById('ef-tipo').value,
    setor: document.getElementById('ef-setor').value.trim(),
    email: document.getElementById('ef-email').value.trim(),
    telefone: document.getElementById('ef-telefone').value.trim(),
    cnpj: document.getElementById('ef-cnpj').value.trim(),
    criticidade: document.getElementById('ef-criticidade').value,
    campos_custom: extras,
  }).eq('id', id);

  if (error) { toast('Erro ao atualizar fornecedor: ' + error.message); return; }

  addLog('fornecedor_editado', `${currentUser.email} editou o cadastro do fornecedor "${nome}"`);
  closeModal();
  await carregarFornecedores();
  renderAdFornecedores();
  toast('Fornecedor atualizado!');
}

async function desativarFornecedorAd(id) {
  const d = db();
  const f = d.fornecedores.find(x => x.id === id);
  if (!f) return;
  if (!confirm(`Desativar "${f.nome}"? Ele sai da lista de ativos, mas fica em "Desativados" e pode ser reativado a qualquer momento. Avaliações e documentos são mantidos.`)) return;

  const { error } = await supabaseClient.from('fornecedores').update({ ativo: false }).eq('id', id);
  if (error) { toast('Erro ao desativar fornecedor: ' + error.message); return; }

  addLog('fornecedor_desativado', `${currentUser.email} desativou o fornecedor "${f.nome}"`);
  await carregarFornecedores();
  renderAdFornecedores();
  toast('Fornecedor desativado.');
}

async function reativarFornecedorAd(id) {
  const d = db();
  const f = d.fornecedores.find(x => x.id === id);
  if (!f) return;

  const { error } = await supabaseClient.from('fornecedores').update({ ativo: true }).eq('id', id);
  if (error) { toast('Erro ao reativar fornecedor: ' + error.message); return; }

  addLog('fornecedor_reativado', `${currentUser.email} reativou o fornecedor "${f.nome}"`);
  await carregarFornecedores();
  renderAdFornecedores();
  toast('Fornecedor reativado!');
}

async function excluirFornecedorDefinitivo(id) {
  const d = db();
  const f = d.fornecedores.find(x => x.id === id);
  if (!f) return;
  if (!confirm(`Excluir "${f.nome}" definitivamente? Essa ação NÃO pode ser desfeita. Documentos e avaliações ligados a ele permanecem no histórico, mas o cadastro será apagado.`)) return;

  const { error } = await supabaseClient.from('fornecedores').delete().eq('id', id);
  if (error) { toast('Erro ao excluir fornecedor: ' + error.message); return; }

  addLog('fornecedor_excluido_definitivo', `${currentUser.email} excluiu definitivamente o fornecedor "${f.nome}"`);
  await carregarFornecedores();
  renderAdFornecedores();
  toast('Fornecedor excluído definitivamente.');
}


// ---------- FORMULÁRIOS ----------
function renderAdFormularios() {
  const d = db();
  document.getElementById('ad-page-formularios').innerHTML = `
    <div class="page-header"><div><h2>Formulários de avaliação</h2><p>Estruturas de critérios usadas pelos setores. ${d.formularios.length} cadastrados.</p></div></div>

    <div class="tab-bar">
      <button class="tab active" onclick="showFormTabAd('catalogo', this)">Catálogo</button>
      <button class="tab" onclick="showFormTabAd('criar', this)">Criar formulário</button>
      <button class="tab" onclick="showFormTabAd('associar', this)">Associar a e-mail</button>
      <button class="tab" onclick="showFormTabAd('campos', this)">Campos institucionais</button>
    </div>

    <div id="form-tab-catalogo" class="form-tab-ad">
      <div class="card">
        <div class="card-title">
          <span>Catálogo de formulários</span>
          <div style="display:flex; align-items:center; gap:8px">
            <button class="btn btn-secondary btn-sm" id="btn-lote-toggle" onclick="toggleModoLote()">Atualizar prazo em lote</button>
          </div>
        </div>
        <div id="lote-actions" style="display:none; margin-bottom:14px; padding:12px 14px; background:var(--accent-bg); border-radius:8px; align-items:center; gap:10px; flex-wrap:wrap">
          <span style="font-size:12px; color:#1d4ed8">Selecione os formulários abaixo e defina a nova data:</span>
          <input type="date" id="lote-data" style="width:160px; padding:6px 8px">
          <button class="btn btn-primary btn-sm" onclick="aplicarPrazoLote()">Aplicar aos selecionados</button>
        </div>
        <div id="formularios-catalogo"></div>
      </div>
    </div>

    <div id="form-tab-criar" class="form-tab-ad" style="display:none">
      <div class="card">
        <div class="card-title" id="nfm-titulo">Novo formulário</div>
        <div class="form-row three">
          <div class="form-group"><label>Nome do formulário</label><input type="text" id="nfm-nome" placeholder="Ex: Manutenção predial"></div>
          <div class="form-group"><label>Setor</label><input type="text" id="nfm-setor" placeholder="Ex: Setor Técnico"></div>
          <div class="form-group"><label>Tipo</label><select id="nfm-tipo"><option value="servico">Serviço</option><option value="produto">Produto</option></select></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Prazo de entrega (dia do mês)</label><input type="number" id="nfm-prazo-dia" min="1" max="28" placeholder="Ex: 5 (dia 5 de cada mês)"></div>
          <div></div>
        </div>

        <p style="font-size:12px; font-weight:600; color:var(--text-sec); margin:6px 0 8px">Campos institucionais deste formulário</p>
        <div id="nfm-campos-extras" style="margin-bottom:16px"></div>

        <div id="nfm-criterios"></div>
        <button class="btn btn-secondary btn-sm" onclick="addCriterioBuilder()" style="margin:8px 0 16px">+ Adicionar critério</button>
        <div style="display:flex; justify-content:space-between; align-items:center; padding-top:12px; border-top:1px solid var(--border)">
          <span style="font-size:12px; color:var(--text-muted)">Total de pontos: <b id="nfm-total-pontos" style="color:var(--text)">0.0</b> (ideal: 10,0)</span>
          <div style="display:flex; gap:8px">
            <button class="btn btn-secondary" id="nfm-cancelar-edicao" style="display:none" onclick="cancelarEdicaoFormulario()">Cancelar edição</button>
            <button class="btn btn-primary" id="nfm-salvar-btn" onclick="salvarNovoFormulario()">Salvar formulário</button>
          </div>
        </div>
      </div>
    </div>

    <div id="form-tab-associar" class="form-tab-ad" style="display:none">
      <div class="card">
        <div class="card-title">Associar e-mail a um formulário</div>
        <p style="font-size:12px; color:var(--text-muted); margin-bottom:14px">É essa associação que define quais formulários aparecem quando o avaliador faz login.</p>
        <div class="form-row three">
          <div class="form-group"><label>E-mail do avaliador</label>
            <select id="assoc-email">${d.usuarios.filter(u=>u.papel==='avaliador').map(u => `<option value="${u.email}">${u.email}</option>`).join('')}</select>
          </div>
          <div class="form-group"><label>Formulário</label>
            <select id="assoc-form">${d.formularios.map(f => `<option value="${f.id}">${f.nome}</option>`).join('')}</select>
          </div>
          <div class="form-group"><label>Fornecedor vinculado (opcional)</label>
            <select id="assoc-fornecedor"><option value="">Nenhum específico</option>${d.fornecedores.map(fn => `<option value="${fn.id}">${fn.nome}</option>`).join('')}</select>
          </div>
        </div>
        <button class="btn btn-primary" onclick="addAssociacao()">Associar</button>
      </div>
      <div class="card">
        <div class="card-title">Associações ativas (${d.associacoes.length})</div>
        <div id="assoc-lista"></div>
      </div>
    </div>

    <div id="form-tab-campos" class="form-tab-ad" style="display:none">
      <div class="card">
        <div class="card-title">Campos institucionais globais</div>
        <p style="font-size:12px; color:var(--text-muted); margin-bottom:14px">Esses campos aparecem por padrão em todo formulário novo (ex: Código do documento, Revisão, PSQ). Você pode sempre editar o valor de um campo específico dentro de cada formulário.</p>
        <div id="campos-globais-lista"></div>
        <div style="display:flex; gap:8px; margin-top:12px">
          <input type="text" id="cg-label" placeholder="Nome do campo (ex: PSQ)" style="flex:1; padding:8px 11px; border:1px solid var(--border); border-radius:8px">
          <input type="text" id="cg-valor" placeholder="Valor padrão (ex: GER.017 Rev.25)" style="flex:1; padding:8px 11px; border:1px solid var(--border); border-radius:8px">
          <button class="btn btn-primary btn-sm" onclick="addCampoGlobal()">+ Adicionar</button>
        </div>
      </div>
    </div>
  `;
  renderAssocLista();
  renderFormulariosCatalogo();
  renderCamposGlobaisLista();
  window._criterioBuilder = [];
  window._camposExtrasBuilder = db().camposGlobais.map(c => ({ ...c }));
  window._editandoFormularioId = null;
  renderCriteriosBuilder();
  renderCamposExtrasBuilder();
}

function showFormTabAd(tab, btn) {
  document.querySelectorAll('.form-tab-ad').forEach(el => el.style.display = 'none');
  document.querySelectorAll('#ad-page-formularios > .tab-bar > .tab').forEach(el => el.classList.remove('active'));
  document.getElementById('form-tab-' + tab).style.display = 'block';
  btn.classList.add('active');
}

// ---- Campos institucionais globais ----
function renderCamposGlobaisLista() {
  const d = db();
  const wrap = document.getElementById('campos-globais-lista');
  if (!wrap) return;
  if (!d.camposGlobais.length) { wrap.innerHTML = '<p style="font-size:12px; color:var(--text-muted)">Nenhum campo global definido.</p>'; return; }
  wrap.innerHTML = d.camposGlobais.map((c, i) => `
    <div style="display:flex; align-items:center; gap:10px; padding:8px 0; border-bottom:1px solid var(--border); font-size:13px">
      <span style="font-weight:500; min-width:140px">${c.label}</span>
      <span style="color:var(--text-muted); flex:1">${c.valor}</span>
      <button class="btn btn-danger btn-sm" onclick="removeCampoGlobal(${i})">Remover</button>
    </div>
  `).join('');
}

function addCampoGlobal() {
  const label = document.getElementById('cg-label').value.trim();
  const valor = document.getElementById('cg-valor').value.trim();
  if (!label) { toast('Informe o nome do campo.'); return; }
  const d = db();
  d.camposGlobais.push({ chave: 'cg' + Date.now(), label, valor });
  save('ap_campos_globais', d.camposGlobais);
  addLog('campo_global_criado', `${currentUser.email} criou o campo institucional global "${label}"`);
  document.getElementById('cg-label').value = '';
  document.getElementById('cg-valor').value = '';
  renderCamposGlobaisLista();
  toast('Campo adicionado.');
}

function removeCampoGlobal(i) {
  const d = db();
  const c = d.camposGlobais[i];
  if (!confirm(`Remover o campo "${c.label}"? Isso não altera formulários já criados.`)) return;
  d.camposGlobais.splice(i, 1);
  save('ap_campos_globais', d.camposGlobais);
  addLog('campo_global_removido', `${currentUser.email} removeu o campo institucional global "${c.label}"`);
  renderCamposGlobaisLista();
}

// ---- Campos extras por formulário (builder) ----
function renderCamposExtrasBuilder() {
  const wrap = document.getElementById('nfm-campos-extras');
  if (!wrap) return;
  if (!window._camposExtrasBuilder.length) {
    wrap.innerHTML = '<p style="font-size:12px; color:var(--text-muted)">Nenhum campo institucional. Adicione em "Campos institucionais" ou inclua um específico abaixo.</p>';
  } else {
    wrap.innerHTML = window._camposExtrasBuilder.map((c, i) => `
      <div style="display:flex; align-items:center; gap:8px; margin-bottom:6px">
        <input type="text" value="${c.label}" placeholder="Nome do campo" style="width:160px" oninput="window._camposExtrasBuilder[${i}].label=this.value">
        <input type="text" value="${c.valor}" placeholder="Valor" style="flex:1" oninput="window._camposExtrasBuilder[${i}].valor=this.value">
        <button class="btn btn-danger btn-sm" onclick="removeCampoExtraBuilder(${i})">✕</button>
      </div>
    `).join('');
  }
  wrap.innerHTML += `<button class="btn btn-secondary btn-sm" onclick="addCampoExtraBuilder()" style="margin-top:4px">+ Campo específico deste formulário</button>`;
}

function addCampoExtraBuilder() {
  window._camposExtrasBuilder.push({ chave: 'ce' + Date.now(), label: '', valor: '' });
  renderCamposExtrasBuilder();
}
function removeCampoExtraBuilder(i) {
  window._camposExtrasBuilder.splice(i, 1);
  renderCamposExtrasBuilder();
}

// ---- Modo lote de prazo de entrega ----
function toggleModoLote() {
  window._modoLote = !window._modoLote;
  document.getElementById('lote-actions').style.display = window._modoLote ? 'flex' : 'none';
  document.getElementById('btn-lote-toggle').textContent = window._modoLote ? 'Cancelar seleção' : 'Atualizar prazo em lote';
  renderFormulariosCatalogo();
}

function aplicarPrazoLote() {
  const novaData = document.getElementById('lote-data').value;
  if (!novaData) { toast('Selecione uma data.'); return; }
  const checks = document.querySelectorAll('.lote-check:checked');
  if (!checks.length) { toast('Selecione ao menos um formulário.'); return; }
  const d = db();
  let count = 0;
  checks.forEach(chk => {
    const f = d.formularios.find(x => x.id === chk.value);
    if (f) { f.prazoEntrega = novaData; count++; }
  });
  save('ap_formularios', d.formularios);
  addLog('prazo_lote_atualizado', `${currentUser.email} atualizou o prazo de entrega para ${novaData} em ${count} formulário(s)`);
  toast(`Prazo atualizado em ${count} formulário(s).`);
  window._modoLote = false;
  document.getElementById('lote-actions').style.display = 'none';
  document.getElementById('btn-lote-toggle').textContent = 'Atualizar prazo em lote';
  renderFormulariosCatalogo();
}

// ---- Construtor de critérios/opções ----
function addCriterioBuilder() {
  window._criterioBuilder.push({ tempId: 'tc' + Date.now(), nome: '', pesoMax: 0, opcoes: [{ label: '', pontos: 0 }] });
  renderCriteriosBuilder();
}

function removeCriterioBuilder(tempId) {
  window._criterioBuilder = window._criterioBuilder.filter(c => c.tempId !== tempId);
  renderCriteriosBuilder();
}

function addOpcaoBuilder(tempId) {
  const crit = window._criterioBuilder.find(c => c.tempId === tempId);
  crit.opcoes.push({ label: '', pontos: 0 });
  renderCriteriosBuilder();
}

function removeOpcaoBuilder(tempId, idx) {
  const crit = window._criterioBuilder.find(c => c.tempId === tempId);
  crit.opcoes.splice(idx, 1);
  renderCriteriosBuilder();
}

function updateCriterioField(tempId, field, value) {
  const crit = window._criterioBuilder.find(c => c.tempId === tempId);
  crit[field] = field === 'pesoMax' ? parseFloat(value) || 0 : value;
  updateTotalPontosPreview();
}

function updateOpcaoField(tempId, idx, field, value) {
  const crit = window._criterioBuilder.find(c => c.tempId === tempId);
  crit.opcoes[idx][field] = field === 'pontos' ? parseFloat(value) || 0 : value;
}

function updateTotalPontosPreview() {
  const total = window._criterioBuilder.reduce((s,c) => s + (c.pesoMax || 0), 0);
  const el = document.getElementById('nfm-total-pontos');
  if (el) el.textContent = total.toFixed(1);
}

function renderCriteriosBuilder() {
  const wrap = document.getElementById('nfm-criterios');
  if (!wrap) return;
  if (!window._criterioBuilder.length) {
    wrap.innerHTML = '<div class="empty-state" style="padding:24px"><p>Nenhum critério adicionado. Clique em "Adicionar critério" abaixo.</p></div>';
    return;
  }
  wrap.innerHTML = window._criterioBuilder.map(c => `
    <div class="criterio-block">
      <div class="form-row" style="margin-bottom:10px">
        <div class="form-group"><label>Nome do critério</label><input type="text" value="${c.nome}" placeholder="Ex: Atendimento" oninput="updateCriterioField('${c.tempId}','nome',this.value)"></div>
        <div class="form-group"><label>Peso máximo (pontos)</label><input type="number" step="0.1" value="${c.pesoMax || ''}" placeholder="Ex: 3.0" oninput="updateCriterioField('${c.tempId}','pesoMax',this.value); updateTotalPontosPreview()"></div>
      </div>
      <p style="font-size:11px; font-weight:600; color:var(--text-muted); margin-bottom:8px">Opções de resposta e pontuação</p>
      ${c.opcoes.map((op, i) => `
        <div style="display:flex; gap:8px; align-items:center; margin-bottom:6px">
          <input type="text" value="${op.label}" placeholder="Ex: Dentro da expectativa" style="flex:1" oninput="updateOpcaoField('${c.tempId}',${i},'label',this.value)">
          <input type="number" step="0.1" value="${op.pontos || ''}" placeholder="Pts" style="width:70px" oninput="updateOpcaoField('${c.tempId}',${i},'pontos',this.value)">
          <button class="btn btn-danger btn-sm" onclick="removeOpcaoBuilder('${c.tempId}',${i})">✕</button>
        </div>
      `).join('')}
      <div style="display:flex; justify-content:space-between; margin-top:8px">
        <button class="btn btn-secondary btn-sm" onclick="addOpcaoBuilder('${c.tempId}')">+ Opção</button>
        <button class="btn btn-danger btn-sm" onclick="removeCriterioBuilder('${c.tempId}')">Remover critério</button>
      </div>
    </div>
  `).join('');
  updateTotalPontosPreview();
}

function editarFormulario(id) {
  const d = db();
  const f = d.formularios.find(x => x.id === id);
  if (!f) return;

  window._editandoFormularioId = id;
  window._criterioBuilder = f.criterios.map(c => ({
    tempId: c.id,
    nome: c.nome,
    pesoMax: c.pesoMax,
    opcoes: c.opcoes.map(o => ({ ...o }))
  }));
  window._camposExtrasBuilder = (f.camposExtras || []).map(c => ({ ...c }));

  // muda para a aba criar
  document.querySelectorAll('.form-tab-ad').forEach(el => el.style.display = 'none');
  document.querySelectorAll('#ad-page-formularios > .tab-bar > .tab').forEach(el => el.classList.remove('active'));
  document.getElementById('form-tab-criar').style.display = 'block';
  document.querySelectorAll('#ad-page-formularios > .tab-bar > .tab')[1].classList.add('active');

  document.getElementById('nfm-titulo').textContent = `Editando: ${f.nome}`;
  document.getElementById('nfm-nome').value = f.nome;
  document.getElementById('nfm-setor').value = f.setor;
  document.getElementById('nfm-tipo').value = f.tipo;
  document.getElementById('nfm-prazo-dia').value = f.prazoEntregaDia || '';
  document.getElementById('nfm-cancelar-edicao').style.display = 'inline-flex';
  document.getElementById('nfm-salvar-btn').textContent = 'Salvar alterações';

  renderCriteriosBuilder();
  renderCamposExtrasBuilder();
}

function cancelarEdicaoFormulario() {
  window._editandoFormularioId = null;
  window._criterioBuilder = [];
  window._camposExtrasBuilder = db().camposGlobais.map(c => ({ ...c }));
  document.getElementById('nfm-titulo').textContent = 'Novo formulário';
  document.getElementById('nfm-nome').value = '';
  document.getElementById('nfm-setor').value = '';
  document.getElementById('nfm-prazo-dia').value = '';
  document.getElementById('nfm-cancelar-edicao').style.display = 'none';
  document.getElementById('nfm-salvar-btn').textContent = 'Salvar formulário';
  renderCriteriosBuilder();
  renderCamposExtrasBuilder();
}

async function salvarNovoFormulario() {
  const nome = document.getElementById('nfm-nome').value.trim();
  const setor = document.getElementById('nfm-setor').value.trim();
  const tipo = document.getElementById('nfm-tipo').value;
  const prazoDia = document.getElementById('nfm-prazo-dia').value;

  if (!nome || !setor) { toast('Informe o nome e o setor do formulário.'); return; }
  if (!window._criterioBuilder.length) { toast('Adicione ao menos um critério.'); return; }

  for (const c of window._criterioBuilder) {
    if (!c.nome.trim()) { toast('Todos os critérios precisam de um nome.'); return; }
    if (!c.pesoMax || c.pesoMax <= 0) { toast(`Defina o peso máximo do critério "${c.nome}".`); return; }
    if (!c.opcoes.length || c.opcoes.some(o => !o.label.trim())) { toast(`Preencha o texto de todas as opções do critério "${c.nome}".`); return; }
  }

  const camposExtras = window._camposExtrasBuilder.filter(c => c.label.trim()).map(c => ({ chave: c.chave, label: c.label.trim(), valor: c.valor.trim() }));
  const criterios = window._criterioBuilder.map((c, i) => ({
    id: (c.tempId && c.tempId.startsWith('tc')) ? 'c' + (i + 1) : (c.tempId || 'c' + (i + 1)),
    nome: c.nome.trim(),
    pesoMax: c.pesoMax,
    opcoes: c.opcoes.map(o => ({ label: o.label.trim(), pontos: o.pontos })),
  }));

  const payload = {
    nome, setor, tipo,
    prazo_entrega_dia: prazoDia ? parseInt(prazoDia) : null,
    campos_extras: camposExtras,
    criterios,
  };

  if (window._editandoFormularioId) {
    const { error } = await supabaseClient.from('formularios').update(payload).eq('id', window._editandoFormularioId);
    if (error) { toast('Erro ao atualizar formulário: ' + error.message); return; }
    addLog('formulario_editado', `${currentUser.email} editou o formulário "${nome}"`);
    toast('Formulário atualizado!');
  } else {
    const { error } = await supabaseClient.from('formularios').insert({ ...payload, empresa_id: currentUser.empresaId });
    if (error) { toast('Erro ao criar formulário: ' + error.message); return; }
    addLog('formulario_criado', `${currentUser.email} criou o formulário "${nome}" (setor: ${setor}, ${criterios.length} critérios)`);
    toast('Formulário criado! Agora associe a um e-mail na aba "Associar a e-mail".');
  }

  window._criterioBuilder = [];
  window._editandoFormularioId = null;
  await carregarFormularios();
  renderAdFormularios();
}


function renderAssocLista() {
  const d = db();
  const wrap = document.getElementById('assoc-lista');
  if (!d.associacoes.length) { wrap.innerHTML = '<div class="empty-state"><p>Nenhuma associação configurada.</p></div>'; return; }
  wrap.innerHTML = `<table><thead><tr><th>E-mail</th><th>Formulário</th><th>Fornecedor</th><th></th></tr></thead><tbody>
    ${d.associacoes.map(a => {
      const usuario = d.usuarios.find(u => u.id === a.usuarioId);
      const form = d.formularios.find(f => f.id === a.formularioId);
      const forn = a.fornecedorId ? d.fornecedores.find(f => f.id === a.fornecedorId) : null;
      return `<tr>
        <td style="font-weight:500">${usuario ? usuario.email : '—'}</td>
        <td>${form ? form.nome : '—'}</td>
        <td style="color:var(--text-sec)">${forn ? forn.nome : '—'}</td>
        <td><div class="actions"><button class="btn btn-danger btn-sm" onclick="removeAssociacao('${a.id}')">Remover</button></div></td>
      </tr>`;
    }).join('')}
  </tbody></table>`;
}

async function addAssociacao() {
  const email = document.getElementById('assoc-email').value;
  const formularioId = document.getElementById('assoc-form').value;
  const fornecedorId = document.getElementById('assoc-fornecedor').value || null;
  if (!email || !formularioId) { toast('Selecione e-mail e formulário.'); return; }
  const d = db();
  const usuario = d.usuarios.find(u => u.email.toLowerCase() === email.toLowerCase());
  if (!usuario) { toast('Usuário não encontrado.'); return; }

  const { error } = await supabaseClient.from('associacoes').insert({
    empresa_id: currentUser.empresaId,
    usuario_id: usuario.id,
    formulario_id: formularioId,
    fornecedor_id: fornecedorId,
  });

  if (error) { toast('Erro ao criar associação: ' + error.message); return; }

  const form = d.formularios.find(f => f.id === formularioId);
  addLog('associacao_criada', `${currentUser.email} associou o formulário "${form.nome}" ao e-mail ${email}`);
  await carregarAssociacoes();
  renderAssocLista();
  toast('Associação criada!');
}

async function removeAssociacao(id) {
  const { error } = await supabaseClient.from('associacoes').delete().eq('id', id);
  if (error) { toast('Erro ao remover associação: ' + error.message); return; }
  addLog('associacao_removida', `${currentUser.email} removeu uma associação de formulário`);
  await carregarAssociacoes();
  renderAssocLista();
  toast('Associação removida.');
}

function renderFormulariosCatalogo() {
  const d = db();
  const wrap = document.getElementById('formularios-catalogo');
  if (!d.formularios.length) { wrap.innerHTML = '<div class="empty-state"><p>Nenhum formulário cadastrado.</p></div>'; return; }
  const modoLote = !!window._modoLote;
  wrap.innerHTML = d.formularios.map(f => `
    <div style="padding:12px 0; border-bottom:1px solid var(--border)">
      <div style="display:flex; justify-content:space-between; align-items:center">
        <div style="display:flex; align-items:center; gap:10px">
          ${modoLote ? `<input type="checkbox" class="lote-check" value="${f.id}" style="accent-color:var(--accent)">` : ''}
          <div>
            <span style="font-weight:500; font-size:13px">${f.nome}</span>
            <span class="tag-${f.tipo}" style="margin-left:8px">${f.tipo === 'produto' ? 'Produto' : 'Serviço'}</span>
            ${f.prazoEntregaDia ? `<span class="badge badge-accent" style="margin-left:6px">Vence dia ${f.prazoEntregaDia}</span>` : ''}
          </div>
        </div>
        <div style="display:flex; align-items:center; gap:10px">
          <span style="font-size:11px; color:var(--text-muted)">${f.criterios.length} critérios · máx ${f.criterios.reduce((s,c)=>s+c.pesoMax,0).toFixed(1)}P</span>
          <button class="btn btn-secondary btn-sm" onclick="verFormularioDetalhe('${f.id}')">Ver</button>
          <button class="btn btn-secondary btn-sm" onclick="editarFormulario('${f.id}')">Editar</button>
          <button class="btn btn-secondary btn-sm" onclick="duplicarFormularioAd('${f.id}')">Duplicar</button>
          <button class="btn btn-danger btn-sm" onclick="removeFormularioAd('${f.id}')">Remover</button>
        </div>
      </div>
      <p style="font-size:11px; color:var(--text-muted); margin-top:4px">Setor: ${f.setor} · ${f.criterios.map(c=>c.nome).join(', ')}${f.camposExtras && f.camposExtras.length ? ' · ' + f.camposExtras.map(c=>`${c.label}: ${c.valor}`).join(' · ') : ''}</p>
    </div>
  `).join('');
}

async function duplicarFormularioAd(id) {
  const d = db();
  const f = d.formularios.find(x => x.id === id);
  if (!f) return;

  const { error } = await supabaseClient.from('formularios').insert({
    empresa_id: currentUser.empresaId,
    nome: f.nome + ' (cópia)',
    setor: f.setor,
    tipo: f.tipo,
    prazo_entrega_dia: f.prazoEntregaDia,
    campos_extras: f.camposExtras,
    criterios: f.criterios,
  });

  if (error) { toast('Erro ao duplicar formulário: ' + error.message); return; }

  addLog('formulario_duplicado', `${currentUser.email} duplicou o formulário "${f.nome}"`);
  await carregarFormularios();
  renderFormulariosCatalogo();
  toast('Formulário duplicado! Já pode editar o nome e os critérios da cópia.');
}

function verFormularioDetalhe(id) {
  const d = db();
  const f = d.formularios.find(x => x.id === id);
  openModal(`
    <h3>${f.nome}</h3>
    <p style="font-size:12px; color:var(--text-muted); margin-bottom:6px">Setor: ${f.setor} · ${f.tipo === 'produto' ? 'Produto' : 'Serviço'} · máx ${f.criterios.reduce((s,c)=>s+c.pesoMax,0).toFixed(1)}P</p>
    ${f.camposExtras && f.camposExtras.length ? `<p style="font-size:12px; color:var(--text-sec); margin-bottom:14px">${f.camposExtras.map(c=>`<b>${c.label}:</b> ${c.valor}`).join(' &nbsp;·&nbsp; ')}</p>` : ''}
    ${f.prazoEntregaDia ? `<p style="font-size:12px; color:var(--accent); margin-bottom:14px">Prazo de entrega: dia ${f.prazoEntregaDia} de cada mês</p>` : ''}
    ${f.criterios.map(c => `
      <div style="margin-bottom:12px">
        <p style="font-size:12px; font-weight:600">${c.nome} <span style="font-weight:400; color:var(--text-muted)">(até ${c.pesoMax.toFixed(1)}P)</span></p>
        ${c.opcoes.map(o => `<div style="font-size:12px; color:var(--text-sec); padding:2px 0 2px 10px">• ${o.label} — ${o.pontos.toFixed(1)}P</div>`).join('')}
      </div>
    `).join('')}
    <div style="display:flex; justify-content:flex-end; margin-top:14px">
      <button class="btn btn-secondary" onclick="closeModal()">Fechar</button>
    </div>
  `);
}

async function removeFormularioAd(id) {
  const d = db();
  const f = d.formularios.find(x => x.id === id);
  const emUso = d.associacoes.some(a => a.formularioId === id);
  if (emUso) {
    if (!confirm(`"${f.nome}" está associado a um ou mais e-mails. Remover o formulário também removerá essas associações. Continuar?`)) return;
  } else {
    if (!confirm(`Remover o formulário "${f.nome}"?`)) return;
  }

  // O banco já tem "on delete cascade" em associacoes.formulario_id,
  // então apagar o formulário remove as associações dele automaticamente.
  const { error } = await supabaseClient.from('formularios').delete().eq('id', id);
  if (error) { toast('Erro ao remover formulário: ' + error.message); return; }

  addLog('formulario_removido', `${currentUser.email} removeu o formulário "${f.nome}"`);
  await carregarFormularios();
  await carregarAssociacoes();
  renderAdFormularios();
  toast('Formulário removido.');
}

// ---------- USUÁRIOS ----------
function renderAdUsuarios() {
  const d = db();
  document.getElementById('ad-page-usuarios').innerHTML = `
    <div class="page-header"><div><h2>Usuários e acessos</h2><p>Quem pode acessar o sistema. Apenas o admin pode criar ou alterar senhas.</p></div></div>
    <div class="card">
      <div class="card-title">Novo usuário</div>
      <div class="form-row three">
        <div class="form-group"><label>Nome</label><input type="text" id="nu-nome" placeholder="Ex: Setor Compras"></div>
        <div class="form-group"><label>E-mail</label><input type="email" id="nu-email" placeholder="setor@empresa.com"></div>
        <div class="form-group"><label>Papel</label><select id="nu-papel"><option value="avaliador">Avaliador</option><option value="admin">Admin</option></select></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Senha inicial</label><input type="text" id="nu-senha" placeholder="Mín. 6 caracteres"></div>
      </div>
      <button class="btn btn-primary" onclick="addUsuario()">Criar usuário</button>
    </div>
    <div class="card">
      <div class="card-title">Usuários (${d.usuarios.length})</div>
      <div id="usuarios-lista"></div>
    </div>
  `;
  renderUsuariosLista();
}

function renderUsuariosLista() {
  const d = db();
  const wrap = document.getElementById('usuarios-lista');
  wrap.innerHTML = `<table><thead><tr><th>Nome</th><th>E-mail</th><th>Papel</th><th>Status</th><th></th></tr></thead><tbody>
    ${d.usuarios.map(u => `<tr>
      <td style="font-weight:500">${u.nome}</td>
      <td style="color:var(--text-sec)">${u.email}</td>
      <td><span class="role-badge ${u.papel}" style="display:inline-block">${u.papel === 'admin' ? 'Admin' : 'Avaliador'}</span></td>
      <td>${u.ativo ? '<span class="badge badge-success">Ativo</span>' : '<span class="badge badge-neutral">Inativo</span>'}</td>
      <td><div class="actions">
        <button class="btn btn-secondary btn-sm" onclick="resetSenha('${u.id}')">Redefinir senha</button>
        <button class="btn btn-secondary btn-sm" onclick="toggleUsuario('${u.id}')">${u.ativo ? 'Desativar' : 'Ativar'}</button>
        <button class="btn btn-danger btn-sm" onclick="excluirUsuarioAd('${u.id}')">Excluir</button>
      </div></td>
    </tr>`).join('')}
  </tbody></table>`;
}

async function addUsuario() {
  const nome = document.getElementById('nu-nome').value.trim();
  const email = document.getElementById('nu-email').value.trim().toLowerCase();
  const papel = document.getElementById('nu-papel').value;
  const senha = document.getElementById('nu-senha').value;
  if (!nome || !email || senha.length < 6) { toast('Preencha todos os campos. Senha mínima de 6 caracteres.'); return; }

  const btn = document.querySelector('#ad-page-usuarios .btn-primary');
  if (btn) { btn.disabled = true; btn.textContent = 'Criando...'; }

  const { data, error } = await supabaseClient.functions.invoke('admin-criar-usuario', {
    body: { nome, email, senha, papel },
  });

  if (btn) { btn.disabled = false; btn.textContent = 'Criar usuário'; }

  // supabase-js devolve erro de Edge Function em error.context; a mensagem
  // "de negócio" (ex: "já existe") vem no corpo (data.error) quando o status
  // não é 2xx.
  if (error || (data && data.ok === false)) {
    const msg = (data && data.error) || error?.message || 'Erro ao criar usuário.';
    toast(msg);
    return;
  }

  addLog('usuario_criado', `${currentUser.email} criou o usuário ${email} (papel: ${papel})`);
  document.getElementById('nu-nome').value = '';
  document.getElementById('nu-email').value = '';
  document.getElementById('nu-senha').value = '';
  await carregarUsuarios();
  renderAdUsuarios();
  toast('Usuário criado!');
}

function resetSenha(id) {
  const d = db();
  const u = d.usuarios.find(x => x.id === id);
  if (!u) return;
  openModal(`
    <h3>Redefinir senha — ${u.email}</h3>
    <div class="form-group" style="margin-bottom:14px">
      <label>Nova senha</label>
      <input type="text" id="rs-nova-senha" placeholder="Mínimo 6 caracteres">
    </div>
    <div style="display:flex; gap:8px; justify-content:flex-end">
      <button class="btn btn-secondary" onclick="closeModal()">Cancelar</button>
      <button class="btn btn-primary" onclick="confirmarResetSenha('${id}')">Salvar nova senha</button>
    </div>
  `);
}

async function confirmarResetSenha(id) {
  const novaSenha = document.getElementById('rs-nova-senha').value;
  if (novaSenha.length < 6) { toast('Senha deve ter ao menos 6 caracteres.'); return; }
  const d = db();
  const u = d.usuarios.find(x => x.id === id);
  if (!u) return;

  const { data, error } = await supabaseClient.functions.invoke('admin-redefinir-senha', {
    body: { usuarioId: id, novaSenha },
  });

  if (error || (data && data.ok === false)) {
    const msg = (data && data.error) || error?.message || 'Erro ao redefinir senha.';
    toast(msg);
    return;
  }

  addLog('senha_redefinida', `${currentUser.email} redefiniu a senha do usuário ${u.email}`);
  closeModal();
  toast('Senha redefinida com sucesso.');
}

async function toggleUsuario(id) {
  const d = db();
  const u = d.usuarios.find(x => x.id === id);
  if (!u) return;
  const novoStatus = !u.ativo;

  // Ativar/desativar não precisa de Edge Function: é um UPDATE simples em
  // "profiles", permitido pela policy de RLS "admin ativa ou desativa
  // usuarios da empresa" (só funciona dentro da própria empresa).
  const { error } = await supabaseClient
    .from('profiles')
    .update({ ativo: novoStatus })
    .eq('id', id);

  if (error) {
    toast('Erro ao atualizar status: ' + error.message);
    return;
  }

  u.ativo = novoStatus;
  addLog('usuario_status', `${currentUser.email} ${u.ativo ? 'ativou' : 'desativou'} o usuário ${u.email}`);
  renderUsuariosLista();
  toast(`Usuário ${u.ativo ? 'ativado' : 'desativado'}.`);
}

async function excluirUsuarioAd(id) {
  const d = db();
  const u = d.usuarios.find(x => x.id === id);
  if (!u) return;
  if (u.id === currentUser.id) { toast('Você não pode excluir seu próprio usuário.'); return; }
  if (!confirm(`Excluir "${u.nome}" (${u.email}) definitivamente? O login dele deixa de existir e não pode ser desfeito. Avaliações que ele já enviou continuam no histórico normalmente.`)) return;

  const { data, error } = await supabaseClient.functions.invoke('admin-excluir-usuario', {
    body: { usuarioId: id },
  });

  if (error || (data && data.ok === false)) {
    const msg = (data && data.error) || error?.message || 'Erro ao excluir usuário.';
    toast(msg);
    return;
  }

  addLog('usuario_excluido', `${currentUser.email} excluiu definitivamente o usuário ${u.email}`);
  await carregarUsuarios();
  renderUsuariosLista();
  toast('Usuário excluído.');
}

// ---------- AVALIAÇÕES RECEBIDAS ----------
function renderAdAvaliacoes() {
  const d = db();
  document.getElementById('ad-page-avaliacoes').innerHTML = `
    <div class="page-header"><div><h2>Avaliações recebidas</h2><p>Todas as avaliações enviadas pelos setores, com trava de edição</p></div></div>
    <div class="card">
      ${renderAvaliacoesTableComAcoes(d.avaliacoes.slice().sort((a,b) => new Date(b.enviadoEm) - new Date(a.enviadoEm)), d)}
    </div>
  `;
}

function renderAvaliacoesTableComAcoes(lista, d) {
  if (!lista.length) return '<div class="empty-state"><p>Nenhuma avaliação registrada ainda.</p></div>';
  return `<table>
    <thead><tr><th>Formulário</th><th>Fornecedor</th><th>Enviado por</th><th style="text-align:center">Nota</th><th>Situação</th><th>Trava</th><th></th></tr></thead>
    <tbody>
      ${lista.map(av => {
        const form = d.formularios.find(f => f.id === av.formularioId);
        const forn = d.fornecedores.find(f => f.id === av.fornecedorId);
        const sit = av.semServico ? null : getSituacao(av.nota);
        return `<tr>
          <td style="font-weight:500">${form ? form.nome : '—'}</td>
          <td>${forn ? forn.nome : '—'}</td>
          <td style="color:var(--text-sec); font-size:12px">${av.enviadoPor}</td>
          <td style="text-align:center; font-weight:600">${av.semServico ? '—' : av.nota.toFixed(1)}</td>
          <td>${av.semServico ? '<span class="badge badge-neutral">Sem serviço</span>' : badgeSit(sit)}</td>
          <td>${av.liberadoEdicao ? '<span class="badge badge-warn">Liberada</span>' : '<span class="badge badge-neutral">Travada</span>'}</td>
          <td><div class="actions">
            <button class="btn btn-secondary btn-sm" onclick="verDetalheAvaliacao('${av.id}')">Ver</button>
            ${!av.semServico && (sit === 'reprovado' || sit === 'parcial') ? `<button class="btn btn-secondary btn-sm" onclick="abrirNotificacaoAvaliacao('${av.id}')" title="Ver e notificar por e-mail">🔔</button>` : ''}
            ${!av.liberadoEdicao ? `<button class="btn btn-secondary btn-sm" onclick="liberarEdicao('${av.id}')">Liberar edição</button>` : ''}
          </div></td>
        </tr>`;
      }).join('')}
    </tbody>
  </table>`;
}

// Linha de um critério com pontuação obtida/máxima visível — pra deixar claro
// pro fornecedor como a nota foi calculada, não só qual opção foi marcada.
function linhaCriterioHTML(c, r) {
  const naoHouve = r && r.naoHouve;
  const opcaoEscolhidaIndex = (r && !naoHouve) ? r.opcaoIndex : null;

  const opcoesHtml = c.opcoes.map((o, i) => {
    const escolhida = i === opcaoEscolhidaIndex;
    return `<div style="display:flex; justify-content:space-between; gap:8px; padding:4px 8px; border-radius:6px; font-size:12px; ${escolhida ? 'background:var(--accent-bg); border:1px solid var(--accent-border); font-weight:600; color:var(--accent)' : 'color:var(--text-muted)'}">
      <span>${escolhida ? '● ' : '○ '}${o.label}</span>
      <span>${o.pontos.toFixed(1)}P</span>
    </div>`;
  }).join('');

  const naoHouveHtml = `<div style="display:flex; justify-content:space-between; gap:8px; padding:4px 8px; border-radius:6px; font-size:12px; margin-top:2px; ${naoHouve ? 'background:var(--accent-bg); border:1px solid var(--accent-border); font-weight:600; color:var(--accent)' : 'color:var(--text-muted)'}">
    <span>${naoHouve ? '● ' : '○ '}Não houve serviço no mês</span>
    <span>desconsiderado</span>
  </div>`;

  return `<div style="padding:8px 0; border-bottom:1px solid var(--border)">
    <div style="font-size:12px; font-weight:600; margin-bottom:5px">${c.nome} <span style="font-weight:400; color:var(--text-muted)">(até ${c.pesoMax.toFixed(1)}P)</span></div>
    <div style="display:flex; flex-direction:column; gap:2px">${opcoesHtml}${naoHouveHtml}</div>
  </div>`;
}

function verDetalheAvaliacao(id) {
  const d = db();
  const av = d.avaliacoes.find(a => a.id === id);
  const form = d.formularios.find(f => f.id === av.formularioId);
  const forn = d.fornecedores.find(f => f.id === av.fornecedorId);
  const sit = av.semServico ? null : getSituacao(av.nota);
  const [ano, mes] = av.periodo.split('-');
  const camposLinha = (form && form.camposExtras && form.camposExtras.length)
    ? form.camposExtras.filter(c => c.valor).map(c => `<span><b style="font-weight:600">${c.label}:</b> ${c.valor}</span>`).join(' &nbsp;·&nbsp; ')
    : '';

  openModal(`
    <h3>${form ? form.nome : 'Avaliação'}</h3>
    <p style="font-size:12px; color:var(--text-muted); margin-bottom:4px">${forn ? forn.nome + ' · ' : ''}${MESES[parseInt(mes)]} de ${ano}</p>
    <p style="font-size:12px; color:var(--text-muted); margin-bottom:14px">Enviado por ${av.enviadoPor} em ${fmtData(av.enviadoEm)}</p>
    ${camposLinha ? `<div style="padding:10px 14px; background:var(--surface2); border-radius:8px; margin-bottom:14px; font-size:12px; color:var(--text-sec); display:flex; flex-wrap:wrap; gap:12px">${camposLinha}</div>` : ''}
    <div style="margin-bottom:14px">${av.semServico ? '<span class="badge badge-neutral">Sem serviço no mês</span>' : badgeSit(sit)} <b style="margin-left:8px; font-size:15px">${av.semServico ? '' : av.nota.toFixed(1)}</b></div>
    ${form ? form.criterios.map(c => linhaCriterioHTML(c, av.respostas[c.id])).join('') : ''}
    ${av.justificativa ? `<div style="margin-top:12px; padding:10px; background:var(--danger-bg); border-radius:8px; font-size:12px; color:var(--danger)"><b>Melhoria esperada:</b> ${av.justificativa}</div>` : ''}
    ${av.obs ? `<div style="margin-top:8px; font-size:12px; color:var(--text-sec)"><b>Observações:</b> ${av.obs}</div>` : ''}
    ${av.anexos && av.anexos.length ? `<div style="margin-top:10px"><b style="font-size:12px">Anexos:</b>${av.anexos.map(a => `<div class="anexo-item">📎 ${a.nome} <span style="color:var(--text-muted)">${a.tamanho}</span></div>`).join('')}</div>` : ''}
    <div class="no-print" style="display:flex; justify-content:flex-end; gap:8px; margin-top:16px">
      <button class="btn btn-secondary" onclick="window.print()">🖨️ Imprimir</button>
      <button class="btn btn-secondary" onclick="closeModal()">Fechar</button>
    </div>
  `);
}

function liberarEdicao(id) {
  openModal(`
    <h3>Liberar edição</h3>
    <p style="font-size:12px; color:var(--text-muted); margin-bottom:14px">Informe o motivo da liberação. Isso fica registrado no log de auditoria.</p>
    <div class="form-group" style="margin-bottom:14px">
      <label>Motivo</label>
      <textarea id="motivo-liberacao" rows="3" placeholder="Ex: erro de digitação identificado pelo setor"></textarea>
    </div>
    <div style="display:flex; gap:8px; justify-content:flex-end">
      <button class="btn btn-secondary" onclick="closeModal()">Cancelar</button>
      <button class="btn btn-primary" onclick="confirmarLiberacao('${id}')">Liberar edição</button>
    </div>
  `);
}

async function confirmarLiberacao(id) {
  const motivo = document.getElementById('motivo-liberacao').value.trim();
  if (!motivo) { toast('Informe o motivo da liberação.'); return; }
  const d = db();
  const av = d.avaliacoes.find(a => a.id === id);
  if (!av) return;

  const { error } = await supabaseClient
    .from('avaliacoes')
    .update({ liberado_edicao: true, bloqueada: false })
    .eq('id', id);

  if (error) { toast('Erro ao liberar edição: ' + error.message); return; }

  addLog('edicao_liberada', `${currentUser.email} liberou edição da avaliação enviada por ${av.enviadoPor} — motivo: ${motivo}`);
  closeModal();
  await carregarAvaliacoes();
  renderAdAvaliacoes();
  toast('Edição liberada. O setor já pode reenviar.');
}

// ---------- AUDITORIA ----------
function renderAdAuditoria() {
  const d = db();
  document.getElementById('ad-page-auditoria').innerHTML = `
    <div class="page-header"><div><h2>Log de auditoria</h2><p>Histórico completo de ações no sistema — útil para auditorias ISO/ONA</p></div></div>
    <div class="card">
      ${!d.logs.length ? '<div class="empty-state"><p>Nenhum evento registrado ainda.</p></div>' : d.logs.slice(0, 100).map(l => `
        <div class="log-item">
          <div class="log-dot"></div>
          <div class="log-text">
            <span><b>${l.usuario}</b> — ${l.detalhe}</span>
            <div class="log-time">${fmtData(l.timestamp)}</div>
          </div>
        </div>
      `).join('')}
    </div>
  `;
}

// ---------- RELATÓRIO & PDFs ----------
let _ultimosResultadosAd = [];
let _ultimoPeriodoAd = '';
function renderAdRelatorio() {
  const mesAtual = new Date().getMonth() + 1;
  const anoAtual = new Date().getFullYear();
  document.getElementById('ad-page-relatorio').innerHTML = `
    <div class="page-header"><div><h2>Relatório & PDFs</h2><p>Selecione o período e gere certificados e cartas automaticamente</p></div></div>
    <div class="card">
      <div class="card-title">Período de avaliação</div>
      <div class="form-row three">
        <div class="form-group"><label>Mês inicial</label><select id="rel-mes-ini">${MESES.slice(1).map((m,i)=>`<option value="${i+1}" ${i+1===mesAtual?'selected':''}>${m}</option>`).join('')}</select></div>
        <div class="form-group"><label>Ano inicial</label><input type="number" id="rel-ano-ini" value="${anoAtual}"></div>
        <div></div>
        <div class="form-group"><label>Mês final</label><select id="rel-mes-fim">${MESES.slice(1).map((m,i)=>`<option value="${i+1}" ${i+1===mesAtual?'selected':''}>${m}</option>`).join('')}</select></div>
        <div class="form-group"><label>Ano final</label><input type="number" id="rel-ano-fim" value="${anoAtual}"></div>
      </div>
      <button class="btn btn-primary" onclick="gerarRelatorioAd()">Calcular médias</button>
    </div>
    <div id="relatorio-resultado-ad"></div>
  `;
}

function gerarRelatorioAd() {
  const mesIni = parseInt(document.getElementById('rel-mes-ini').value);
  const anoIni = parseInt(document.getElementById('rel-ano-ini').value);
  const mesFim = parseInt(document.getElementById('rel-mes-fim').value);
  const anoFim = parseInt(document.getElementById('rel-ano-fim').value);
  const d = db();

  if (anoIni > anoFim || (anoIni === anoFim && mesIni > mesFim)) { toast('Período inválido.'); return; }

  const periodos = [];
  let m = mesIni, a = anoIni;
  while (a < anoFim || (a === anoFim && m <= mesFim)) { periodos.push(`${a}-${m}`); m++; if (m > 12) { m = 1; a++; } }

  const resultados = d.fornecedores.map(f => {
    const avs = d.avaliacoes.filter(av => av.fornecedorId === f.id && periodos.includes(av.periodo) && !av.semServico);
    if (!avs.length) return null;
    const media = avs.reduce((s, av) => s + av.nota, 0) / avs.length;
    const sit = getSituacao(media);
    return { ...f, media, sit, meses: avs.length, totalMeses: periodos.length };
  }).filter(Boolean);

  const periodoLabel = `${MESES[mesIni]}/${anoIni}` + (mesIni === mesFim && anoIni === anoFim ? '' : ` a ${MESES[mesFim]}/${anoFim}`);
  const wrap = document.getElementById('relatorio-resultado-ad');

  if (!resultados.length) {
    wrap.innerHTML = '<div class="card"><div class="empty-state"><p>Nenhuma avaliação encontrada para fornecedores neste período.</p></div></div>';
    return;
  }

  _ultimosResultadosAd = resultados;
  _ultimoPeriodoAd = periodoLabel;

  wrap.innerHTML = `
    <div class="card">
      <div class="card-title">Resultados — ${periodoLabel}</div>
      <table>
        <thead><tr><th>Fornecedor</th><th>Tipo</th><th style="text-align:center">Média</th><th style="text-align:center">Avaliações</th><th>Situação</th><th style="text-align:right">Ações</th></tr></thead>
        <tbody>
          ${resultados.map(r => `<tr>
            <td style="font-weight:500">${r.nome}</td>
            <td><span class="tag-${r.tipo}">${r.tipo === 'produto' ? 'Produto' : 'Serviço'}</span></td>
            <td style="text-align:center; font-weight:600">${r.media.toFixed(1)}</td>
            <td style="text-align:center; color:var(--text-muted)">${r.meses}/${r.totalMeses}</td>
            <td>${badgeSit(r.sit)}</td>
            <td><div class="actions">
              <button class="btn btn-secondary btn-sm" onclick="baixarPDFIndividual('${r.id}')" title="Gerar apenas o PDF deste fornecedor">📄 PDF</button>
              <button class="btn btn-secondary btn-sm" onclick="enviarCertificadoEmail('${r.id}')" title="Baixa o PDF e abre seu cliente de e-mail">✉️ E-mail</button>
            </div></td>
          </tr>`).join('')}
        </tbody>
      </table>
      <div style="display:flex; justify-content:flex-end; margin-top:18px; gap:10px">
        <button class="btn btn-secondary" onclick='exportarExcelAd(${JSON.stringify(resultados).replace(/'/g,"&apos;")}, "${periodoLabel}")'>Exportar Excel</button>
        <button class="btn btn-success" onclick='gerarPDFsAd(${JSON.stringify(resultados).replace(/'/g,"&apos;")}, "${periodoLabel}")'>📄 Gerar PDFs (ZIP)</button>
      </div>
    </div>
  `;
}

function aplicarTexto(template, fornecedor, nota, periodo, empresa) {
  return template.replace(/{fornecedor}/g, fornecedor).replace(/{nota}/g, nota).replace(/{periodo}/g, periodo).replace(/{empresa}/g, empresa);
}

function getTipoDoc(sit, tipo) {
  if (sit === 'certificado') return tipo === 'produto' ? 'cert-prod' : 'cert-serv';
  if (sit === 'aprovado') return tipo === 'produto' ? 'aprov-prod' : 'aprov-serv';
  if (sit === 'parcial') return 'parcial';
  return 'reprov';
}
function getTituloDoc(sit) { return sit === 'certificado' ? 'CERTIFICADO DE APROVAÇÃO' : 'CARTA DE AVALIAÇÃO'; }
function getSubtituloDoc(sit) {
  if (sit === 'certificado') return 'APROVADO COM NOTA MÁXIMA';
  if (sit === 'aprovado') return 'APROVADO';
  if (sit === 'parcial') return 'PARCIALMENTE APROVADO';
  return 'REPROVADO';
}

function hexParaRGB(hex) {
  const h = (hex || '#000000').replace('#', '');
  return [parseInt(h.substr(0,2),16) || 0, parseInt(h.substr(2,2),16) || 0, parseInt(h.substr(4,2),16) || 0];
}

function gerarPDFDoc(fornecedor, periodo, layoutOverride) {
  const { jsPDF } = window.jspdf;
  const isCert = fornecedor.sit === 'certificado';
  const doc = new jsPDF({ unit: 'mm', format: 'a4', orientation: isCert ? 'landscape' : 'portrait' });
  const d = db();
  const empNome = d.empresa.nome || 'Empresa';
  const tipoDoc = getTipoDoc(fornecedor.sit, fornecedor.tipo);
  const corpoTexto = aplicarTexto(d.textos[tipoDoc] || '', fornecedor.nome, fornecedor.media.toFixed(1), periodo, empNome);
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const L = layoutOverride || getLayout()[isCert ? 'cert' : 'carta'];

  const fundo = load(isCert ? 'ap_fundo_certificado' : 'ap_fundo_carta');
  if (fundo) { try { doc.addImage(fundo, 'JPEG', 0, 0, W, H); } catch(e) {} }

  const ctx = { fornecedor, nota: fornecedor.media.toFixed(1), periodo, empresaNome: empNome, sit: fornecedor.sit, dadosEmpresa: d.empresa, corpoTexto, isCert };
  // cor dinâmica da "situação" (verde/laranja/vermelho), independe da cor configurada no bloco
  const corSituacao = { aprovado: [0,130,60], parcial: [180,100,0], reprovado: [180,0,0], certificado: [0,130,60] }[fornecedor.sit] || [40,40,40];

  (L.blocos || []).forEach(b => {
    const texto = b.tipo === 'fixo' ? b.conteudo : resolveVariavelValor(b.variavel, ctx);
    if (!texto) return;
    const estilo = (b.negrito && b.italico) ? 'bolditalic' : b.negrito ? 'bold' : b.italico ? 'italic' : 'normal';
    doc.setFont(b.fonte || 'helvetica', estilo);
    doc.setFontSize(b.tamanho);
    doc.setTextColor(...(b.variavel === 'situacao' ? corSituacao : hexParaRGB(b.cor)));
    const linhas = doc.splitTextToSize(texto, b.largura || 160);
    let y = b.y;
    linhas.forEach(linha => { doc.text(linha, b.x, y, { align: b.align }); y += b.tamanho * 0.5 + 1; });
  });

  return doc.output('arraybuffer');
}

async function gerarPDFsAd(resultados, periodo) {
  const btn = event.currentTarget;
  btn.disabled = true; btn.textContent = 'Gerando...';
  try {
    const zip = new JSZip();
    resultados.forEach(r => {
      const pdf = gerarPDFDoc(r, periodo);
      const sit = { certificado: 'Certificado', aprovado: 'Aprovado', parcial: 'Parcialmente_Aprovado', reprovado: 'Reprovado' }[r.sit];
      zip.file(`${sit}_${r.nome.replace(/[^a-zA-Z0-9À-ÿ ]/g,'_')}.pdf`, pdf);
    });
    const blob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `Avaliacao_Fornecedores_${periodo.replace(/\//g,'-')}.zip`;
    a.click(); URL.revokeObjectURL(url);
    addLog('pdfs_gerados', `${currentUser.email} gerou ${resultados.length} documentos para o período ${periodo}`);
    toast('PDFs gerados com sucesso!');
  } catch(e) { toast('Erro ao gerar PDFs: ' + e.message); }
  btn.disabled = false; btn.textContent = '📄 Gerar PDFs (ZIP)';
}

function nomeArquivoDoc(r) {
  const sit = { certificado: 'Certificado', aprovado: 'Aprovado', parcial: 'Parcialmente_Aprovado', reprovado: 'Reprovado' }[r.sit];
  return `${sit}_${r.nome.replace(/[^a-zA-Z0-9À-ÿ ]/g,'_')}.pdf`;
}

function baixarPDFIndividual(fornecedorId) {
  const r = _ultimosResultadosAd.find(x => x.id === fornecedorId);
  if (!r) { toast('Gere o relatório novamente antes de baixar.'); return; }
  const pdf = gerarPDFDoc(r, _ultimoPeriodoAd);
  const blob = new Blob([pdf], { type: 'application/pdf' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = nomeArquivoDoc(r);
  a.click(); URL.revokeObjectURL(url);
  addLog('pdf_individual_gerado', `${currentUser.email} gerou o documento individual de "${r.nome}" (${_ultimoPeriodoAd})`);
  toast('PDF gerado!');
  return r;
}

function enviarCertificadoEmail(fornecedorId) {
  const r = _ultimosResultadosAd.find(x => x.id === fornecedorId);
  if (!r) { toast('Gere o relatório novamente antes de enviar.'); return; }
  if (!r.email) { toast(`"${r.nome}" não tem e-mail cadastrado. Adicione em Fornecedores › Editar.`); return; }
  baixarPDFIndividual(fornecedorId);
  const d = db();
  const empNome = d.empresa.nome || 'Empresa';
  const titulo = getTituloDoc(r.sit);
  const assunto = `${titulo} — ${r.nome} (${_ultimoPeriodoAd})`;
  const corpo = `Olá,\n\nSegue referente à avaliação de fornecedores do período ${_ultimoPeriodoAd}: ${titulo.toLowerCase()}.\n\nO arquivo PDF foi baixado automaticamente nesta página (${nomeArquivoDoc(r)}) — por favor, anexe-o a este e-mail antes de enviar.\n\nAtenciosamente,\n${empNome}`;
  const link = `mailto:${encodeURIComponent(r.email)}?subject=${encodeURIComponent(assunto)}&body=${encodeURIComponent(corpo)}`;
  addLog('email_certificado_enviado', `${currentUser.email} abriu o cliente de e-mail para enviar o documento de "${r.nome}"`);
  setTimeout(() => { window.location.href = link; }, 350);
}

// Modal de revisão antes de notificar: mostra a mesma visão de "verDetalheAvaliacao"
// (critérios, nota, justificativa) + um botão para notificar por e-mail — quem decide
// se notifica ou não é o setor, ao ver esse resumo.
function abrirNotificacaoAvaliacao(avId) {
  const d = db();
  const av = d.avaliacoes.find(a => a.id === avId);
  if (!av) return;
  const form = d.formularios.find(f => f.id === av.formularioId);
  const forn = d.fornecedores.find(f => f.id === av.fornecedorId);
  const sit = av.semServico ? null : getSituacao(av.nota);

  openModal(`
    <h3>${form ? form.nome : 'Avaliação'}</h3>
    <p style="font-size:12px; color:var(--text-muted); margin-bottom:14px">${forn ? forn.nome + ' · ' : ''}${av.periodo}</p>
    <div style="margin-bottom:14px">${av.semServico ? '<span class="badge badge-neutral">Sem serviço no mês</span>' : badgeSit(sit)} <b style="margin-left:8px; font-size:15px">${av.semServico ? '' : av.nota.toFixed(1)}</b></div>
    ${(form ? form.criterios : []).map(c => linhaCriterioHTML(c, av.respostas[c.id])).join('')}
    ${av.justificativa ? `<div style="margin-top:12px; padding:10px; background:var(--danger-bg); border-radius:8px; font-size:12px; color:var(--danger)"><b>Melhoria esperada:</b> ${av.justificativa}</div>` : ''}
    ${av.obs ? `<div style="margin-top:8px; font-size:12px; color:var(--text-sec)"><b>Observações:</b> ${av.obs}</div>` : ''}
    ${!forn || !forn.email ? `<p style="margin-top:12px; font-size:12px; color:var(--danger)">Fornecedor sem e-mail cadastrado — não é possível notificar.</p>` : ''}
    <div style="display:flex; justify-content:flex-end; gap:8px; margin-top:16px">
      <button class="btn btn-secondary" onclick="closeModal()">Fechar</button>
      <button class="btn btn-primary" ${!forn || !forn.email ? 'disabled' : ''} onclick="notificarFornecedorNota('${av.id}')">✉️ Notificar por e-mail</button>
    </div>
  `);
}

function saudacaoPorHorario() {
  const h = new Date().getHours();
  if (h >= 5 && h < 12) return 'Bom dia';
  if (h >= 12 && h < 18) return 'Boa tarde';
  return 'Boa noite';
}

// Notifica por e-mail com o conteúdo da avaliação ESCRITO no corpo (sem gerar/anexar PDF) —
// o fornecedor lê os critérios direto no e-mail, como se fosse o formulário em texto.
// Mostra a régua completa de cada critério (todas as opções, marcando a escolhida) e sugere
// automaticamente qual seria a melhor opção em cada critério abaixo do máximo — além da
// "Melhoria esperada" (justificativa) e "Observações" que o setor já preenche no formulário.
function notificarFornecedorNota(avId) {
  const d = db();
  const av = d.avaliacoes.find(a => a.id === avId);
  if (!av) return;
  const forn = d.fornecedores.find(f => f.id === av.fornecedorId);
  if (!forn) return;
  if (!forn.email) { toast(`"${forn.nome}" não tem e-mail cadastrado. Adicione em Fornecedores › Editar.`); return; }
  const form = d.formularios.find(f => f.id === av.formularioId);
  const [ano, mes] = av.periodo.split('-');
  const periodoLabel = `${MESES[parseInt(mes)]}/${ano}`;
  const sit = getSituacao(av.nota);
  const empNome = d.empresa.nome || 'Empresa';
  const saudacao = saudacaoPorHorario();

  const blocosCriterios = [];
  const melhoriasAuto = [];
  let numero = 1;
  (form ? form.criterios : []).forEach(c => {
    const r = av.respostas[c.id];
    if (!r || r.naoHouve) return;
    const escolhida = c.opcoes[r.opcaoIndex];
    if (!escolhida) return;
    const regua = c.opcoes.map((o, i) => `   - ${o.label} — ${o.pontos.toFixed(1)}P${i === r.opcaoIndex ? ' (Sua nota)' : ''}`).join('\n');
    blocosCriterios.push(`${numero}. ${c.nome} (Sua nota: ${escolhida.pontos.toFixed(1)} de ${c.pesoMax.toFixed(1)}P)\nStatus: ${escolhida.label}.\nRégua do critério:\n${regua}`);
    const melhorOpcao = c.opcoes.reduce((best, o) => o.pontos > best.pontos ? o : best, c.opcoes[0]);
    if (melhorOpcao.pontos > escolhida.pontos) melhoriasAuto.push(`${c.nome}: buscar atingir "${melhorOpcao.label}".`);
    numero++;
  });

  const notaMax = form ? form.criterios.reduce((s, c) => s + c.pesoMax, 0) : null;
  const tipoLabel = form ? (form.tipo === 'produto' ? 'Produto' : 'Serviço') : '';
  const setorInfo = form ? `- Setor Avaliador: ${form.setor} · ${tipoLabel} (${form.nome})\n` : '';
  const secaoMelhoriaAuto = melhoriasAuto.length ? `\n📉 Melhoria Esperada para os Próximos Períodos:\n${melhoriasAuto.map(m => `- ${m}`).join('\n')}\n` : '';

  const assunto = `Avaliação de Desempenho de Fornecedores - ${periodoLabel} - ${forn.nome}`;
  let corpo = `${saudacao},\nInformamos que foi concluída a avaliação de desempenho referente ao período de ${periodoLabel}.\n\n${setorInfo}- Nota Obtida: ${av.nota.toFixed(1)}${notaMax ? ` de ${notaMax.toFixed(1)}P` : ''} (${getSubtituloDoc(sit)})\n\n`;
  if (blocosCriterios.length) corpo += `Para sua ciência, detalhamos abaixo os critérios avaliados, a pontuação que sua empresa obteve e a nossa régua completa de avaliação:\n\n${blocosCriterios.join('\n\n')}\n${secaoMelhoriaAuto}`;
  if (av.justificativa) corpo += `\nOutras melhorias apontadas pelo setor avaliador:\n${av.justificativa}\n`;
  if (av.obs) corpo += `\nObservações:\n${av.obs}\n`;
  corpo += `\nApresentamos esses dados para que sua equipe possa analisar os pontos de melhoria e alinhar os processos internos. Permanecemos à disposição para esclarecer dúvidas e apoiar no que for necessário para buscarmos juntos a evolução dessa nota.\n\nAtenciosamente,\n${empNome}`;

  const link = `mailto:${encodeURIComponent(forn.email)}?subject=${encodeURIComponent(assunto)}&body=${encodeURIComponent(corpo)}`;
  addLog('notificacao_nota_enviada', `${currentUser.email} notificou "${forn.nome}" sobre a nota do período ${periodoLabel}`);
  closeModal();
  window.location.href = link;
}

function enviarCobrancaDocumento(docId) {
  const d = db();
  const doc = d.documentos.find(x => x.id === docId);
  if (!doc) return;
  const forn = d.fornecedores.find(f => f.id === doc.fornecedorId);
  if (!forn) return;
  if (!forn.email) { toast(`"${forn.nome}" não tem e-mail cadastrado. Adicione em Fornecedores › Editar.`); return; }
  const dias = Math.abs(diasParaVencer(doc.validade));
  const dataFmt = new Date(doc.validade + 'T00:00:00').toLocaleDateString('pt-BR');
  const empNome = d.empresa.nome || 'Empresa';
  const assunto = `Documento vencido — ${doc.nome} — ${forn.nome}`;
  const corpo = `Olá,\n\nIdentificamos que o documento "${doc.nome}" referente ao cadastro de fornecedores está vencido desde ${dataFmt} (${dias} dia(s)).\n\nSolicitamos o envio da versão atualizada com a maior brevidade possível, para mantermos seu cadastro regularizado.\n\nAtenciosamente,\n${empNome}`;
  const link = `mailto:${encodeURIComponent(forn.email)}?subject=${encodeURIComponent(assunto)}&body=${encodeURIComponent(corpo)}`;
  addLog('cobranca_enviada', `${currentUser.email} enviou cobrança do documento "${doc.nome}" vencido para "${forn.nome}"`);
  window.location.href = link;
}

function exportarExcelAd(resultados, periodo) {
  const linhas = [['Nome', 'Tipo', 'Média', 'Situação']];
  resultados.forEach(r => linhas.push([r.nome, r.tipo === 'produto' ? 'Produto' : 'Serviço', r.media.toFixed(1), getSubtituloDoc(r.sit)]));
  const csv = linhas.map(l => l.map(c => `"${String(c).replace(/"/g,'""')}"`).join(',')).join('\n');
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = `Fornecedores_${periodo.replace(/\//g,'-')}.csv`; a.click();
  URL.revokeObjectURL(url);
  toast('Planilha exportada!');
}

// ---------- CONFIG ----------
function renderAdConfig() {
  const d = db();
  document.getElementById('ad-page-config').innerHTML = `
    <div class="page-header"><div><h2>Configurações</h2><p>Matriz de qualificação, textos e dados da empresa</p></div></div>

    <div class="tab-bar">
      <button class="tab active" onclick="showConfigTabAd('matriz', this)">Matriz de qualificação</button>
      <button class="tab" onclick="showConfigTabAd('textos', this)">Textos dos documentos</button>
      <button class="tab" onclick="showConfigTabAd('layout', this)">Layout dos documentos</button>
      <button class="tab" onclick="showConfigTabAd('camposfor', this)">Campos do fornecedor</button>
      <button class="tab" onclick="showConfigTabAd('tiposdoc', this)">Tipos de documento</button>
      <button class="tab" onclick="showConfigTabAd('empresa', this)">Minha empresa</button>
    </div>

    <div id="config-tab-matriz" class="config-tab-ad">
      <div class="card">
        <div class="card-title">Faixas de pontuação</div>
        <div style="display:flex; flex-direction:column; gap:10px; margin-bottom:16px">
          <div style="display:flex; align-items:center; gap:10px; padding:10px 14px; background:var(--surface2); border-radius:8px">
            <label style="font-size:12px; font-weight:500; min-width:220px">🏆 Certificado (nota exata mínima)</label>
            <input type="number" id="corte-cert" step="0.1" value="${d.matriz.cert}" style="width:80px; padding:5px 8px">
          </div>
          <div style="display:flex; align-items:center; gap:10px; padding:10px 14px; background:var(--surface2); border-radius:8px">
            <label style="font-size:12px; font-weight:500; min-width:220px">✅ Aprovado (nota mínima)</label>
            <input type="number" id="corte-aprov" step="0.1" value="${d.matriz.aprov}" style="width:80px; padding:5px 8px">
          </div>
          <div style="display:flex; align-items:center; gap:10px; padding:10px 14px; background:var(--surface2); border-radius:8px">
            <label style="font-size:12px; font-weight:500; min-width:220px">⚠️ Parcialmente aprovado (nota mínima)</label>
            <input type="number" id="corte-parcial" step="0.1" value="${d.matriz.parcial}" style="width:80px; padding:5px 8px">
          </div>
          <div style="padding:10px 14px; font-size:12px; color:var(--text-muted)">❌ Reprovado: abaixo do parcialmente aprovado — exige indicação obrigatória de melhoria esperada pelo avaliador.</div>
        </div>
        <button class="btn btn-primary" onclick="salvarMatriz()">Salvar matriz</button>
      </div>
    </div>

    <div id="config-tab-textos" class="config-tab-ad" style="display:none">
      <div class="card">
        <p style="font-size:12px; color:var(--text-muted); margin-bottom:14px; padding:10px 14px; background:var(--surface2); border-radius:8px">
          💡 Esses textos-padrão são usados na geração de PDFs em "Relatório & PDFs" (fechamento semestral ou de qualquer período).
        </p>
        <div class="tab-bar">
          <button class="tab active" onclick="showTextoSubtab('cert-prod', this)">Nota máxima · Produto</button>
          <button class="tab" onclick="showTextoSubtab('cert-serv', this)">Nota máxima · Serviço</button>
          <button class="tab" onclick="showTextoSubtab('aprov-prod', this)">Aprovado · Produto</button>
          <button class="tab" onclick="showTextoSubtab('aprov-serv', this)">Aprovado · Serviço</button>
          <button class="tab" onclick="showTextoSubtab('parcial', this)">Parcial (padrão semestral)</button>
          <button class="tab" onclick="showTextoSubtab('reprov', this)">Reprovado (padrão semestral)</button>
        </div>
        ${Object.keys(d.textos).map(k => `
          <div id="texto-subtab-${k}" class="texto-subtab" style="${k === 'cert-prod' ? '' : 'display:none'}">
            <div class="form-group" style="margin-bottom:10px">
              <label>Corpo do texto</label>
              <textarea id="txt-${k}" rows="6">${d.textos[k]}</textarea>
              <p style="font-size:11px; color:var(--text-muted); margin-top:4px">Variáveis: <code>{fornecedor}</code> <code>{nota}</code> <code>{periodo}</code> <code>{empresa}</code></p>
            </div>
          </div>
        `).join('')}
        <button class="btn btn-primary" onclick="salvarTextosAd()">Salvar todos os textos</button>
      </div>
    </div>

    <div id="config-tab-layout" class="config-tab-ad" style="display:none">
      <div class="card">
        <div class="card-title">Posição dos textos no documento</div>
        <p style="font-size:12px; color:var(--text-muted); margin-bottom:6px">Arraste os blocos na pré-visualização para reposicionar, ou digite as coordenadas exatas (em mm) na tabela ao lado.</p>
        <div class="tab-bar">
          <button class="tab active" onclick="showLayoutSubtab('cert', this)">Certificado (paisagem · nota 10)</button>
          <button class="tab" onclick="showLayoutSubtab('carta', this)">Carta (retrato · demais notas)</button>
        </div>
        <div id="layout-editor-cert" class="layout-editor-wrap"></div>
        <div id="layout-editor-carta" class="layout-editor-wrap" style="display:none"></div>
      </div>
      <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px">
        <div class="card" style="margin-bottom:0">
          <div class="card-title">Imagem de fundo — Certificado (paisagem A4)</div>
          <p style="font-size:12px; color:var(--text-muted); margin-bottom:14px">Faça upload de uma imagem (PNG ou JPG) para usar como fundo do certificado de aprovação. O sistema sobrepõe o texto automaticamente. Tamanho ideal: 3508 × 2480 px.</p>
          <div id="fundo-cert-preview" style="margin-bottom:12px"></div>
          <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap">
            <button class="btn btn-secondary" onclick="document.getElementById('upload-fundo-cert').click()">📎 Selecionar imagem</button>
            <button class="btn btn-danger btn-sm" onclick="removerFundo('ap_fundo_certificado', 'fundo-cert-preview')">Remover fundo</button>
          </div>
          <input type="file" id="upload-fundo-cert" accept="image/*" style="display:none" onchange="uploadFundo('ap_fundo_certificado', this, 'fundo-cert-preview')">
        </div>
        <div class="card" style="margin-bottom:0">
          <div class="card-title">Imagem de fundo — Cartas (retrato A4)</div>
          <p style="font-size:12px; color:var(--text-muted); margin-bottom:14px">Fundo usado nas cartas de aprovação, parcial e reprovação. Tamanho ideal: 2480 × 3508 px.</p>
          <div id="fundo-carta-preview" style="margin-bottom:12px"></div>
          <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap">
            <button class="btn btn-secondary" onclick="document.getElementById('upload-fundo-carta').click()">📎 Selecionar imagem</button>
            <button class="btn btn-danger btn-sm" onclick="removerFundo('ap_fundo_carta', 'fundo-carta-preview')">Remover fundo</button>
          </div>
          <input type="file" id="upload-fundo-carta" accept="image/*" style="display:none" onchange="uploadFundo('ap_fundo_carta', this, 'fundo-carta-preview')">
        </div>
      </div>
    </div>

    <div id="config-tab-camposfor" class="config-tab-ad" style="display:none">
      <div class="card">
        <div class="card-title">Campos personalizados do fornecedor</div>
        <p style="font-size:12px; color:var(--text-muted); margin-bottom:14px">Além de nome, tipo, setor, e-mail, CNPJ e criticidade, você pode adicionar outros campos (ex: contrato, contato responsável, categoria). Eles aparecem automaticamente no cadastro de fornecedores.</p>
        <div id="campos-fornecedor-lista" style="margin-bottom:16px"></div>
        <div class="form-row three">
          <div class="form-group"><label>Chave (sem espaço/acento)</label><input type="text" id="ncf-chave" placeholder="ex: categoria"></div>
          <div class="form-group"><label>Rótulo (exibido)</label><input type="text" id="ncf-label" placeholder="ex: Categoria"></div>
          <div class="form-group"><label>Tipo de campo</label>
            <select id="ncf-tipo" onchange="document.getElementById('ncf-opcoes-wrap').style.display = this.value === 'select' ? 'flex' : 'none'">
              <option value="texto">Texto</option>
              <option value="select">Lista (opções)</option>
              <option value="data">Data</option>
            </select>
          </div>
        </div>
        <div class="form-group" id="ncf-opcoes-wrap" style="display:none; margin-bottom:14px">
          <label>Opções (separadas por vírgula)</label>
          <input type="text" id="ncf-opcoes" placeholder="ex: Nacional, Importado, Local">
        </div>
        <button class="btn btn-primary" onclick="addCampoFornecedorCustom()">Adicionar campo</button>
      </div>
    </div>

    <div id="config-tab-tiposdoc" class="config-tab-ad" style="display:none">
      <div class="card">
        <div class="card-title">Tipos de documento</div>
        <p style="font-size:12px; color:var(--text-muted); margin-bottom:14px">Cadastre os tipos de documento mais usados (ex: Alvará de Funcionamento, CRT, Contrato). Eles aparecem como sugestão ao arquivar um documento de fornecedor — você ainda pode digitar um nome diferente se precisar.</p>
        <div id="tipos-documento-lista" style="display:flex; flex-wrap:wrap; gap:8px; margin-bottom:18px"></div>
        <div class="form-row" style="grid-template-columns:1fr auto">
          <div class="form-group"><label>Novo tipo de documento</label><input type="text" id="ntd-nome" placeholder="ex: Licença Ambiental" onkeydown="if(event.key==='Enter'){event.preventDefault(); addTipoDocumento();}"></div>
          <button class="btn btn-primary" style="align-self:flex-end; height:38px" onclick="addTipoDocumento()">Adicionar</button>
        </div>
      </div>
    </div>


    <div id="config-tab-empresa" class="config-tab-ad" style="display:none">
      <div class="card">
        <div class="form-row">
          <div class="form-group"><label>Nome da empresa</label><input type="text" id="emp-nome" value="${d.empresa.nome||''}"></div>
          <div class="form-group"><label>Cidade/UF</label><input type="text" id="emp-cidade" value="${d.empresa.cidade||''}"></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Endereço</label><input type="text" id="emp-endereco" value="${d.empresa.endereco||''}"></div>
          <div class="form-group"><label>CEP</label><input type="text" id="emp-cep" value="${d.empresa.cep||''}"></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Telefone</label><input type="text" id="emp-tel" value="${d.empresa.tel||''}"></div>
          <div class="form-group"><label>E-mail</label><input type="text" id="emp-email" value="${d.empresa.email||''}"></div>
        </div>
        <button class="btn btn-primary" onclick="salvarEmpresaAd()">Salvar dados</button>
      </div>
    </div>
  `;
}

function showConfigTabAd(tab, btn) {
  document.querySelectorAll('.config-tab-ad').forEach(el => el.style.display = 'none');
  document.querySelectorAll('#ad-page-config > .tab-bar > .tab').forEach(el => el.classList.remove('active'));
  document.getElementById('config-tab-' + tab).style.display = 'block';
  btn.classList.add('active');
}
function showTextoSubtab(tab, btn) {
  document.querySelectorAll('.texto-subtab').forEach(el => el.style.display = 'none');
  btn.parentElement.querySelectorAll('.tab').forEach(el => el.classList.remove('active'));
  document.getElementById('texto-subtab-' + tab).style.display = 'block';
  btn.classList.add('active');
}

function salvarMatriz() {
  const matriz = {
    cert: parseFloat(document.getElementById('corte-cert').value),
    aprov: parseFloat(document.getElementById('corte-aprov').value),
    parcial: parseFloat(document.getElementById('corte-parcial').value)
  };
  save('ap_matriz', matriz);
  addLog('matriz_atualizada', `${currentUser.email} atualizou a matriz de qualificação (cert:${matriz.cert} aprov:${matriz.aprov} parcial:${matriz.parcial})`);
  toast('Matriz de qualificação salva!');
}

function salvarTextosAd() {
  const textos = {};
  ['cert-prod','cert-serv','aprov-prod','aprov-serv','parcial','reprov'].forEach(k => {
    textos[k] = document.getElementById('txt-' + k).value;
  });
  save('ap_textos', textos);
  addLog('textos_atualizados', `${currentUser.email} atualizou os textos dos documentos`);
  toast('Textos salvos!');
}

function salvarEmpresaAd() {
  const empresa = {};
  ['nome','cidade','endereco','cep','tel','email'].forEach(k => {
    empresa[k] = document.getElementById('emp-' + k).value.trim();
  });
  save('ap_empresa', empresa);
  addLog('empresa_atualizada', `${currentUser.email} atualizou os dados da empresa`);
  toast('Dados da empresa salvos!');
}

// ---- Upload de fundo de documento ----
function uploadFundo(storageKey, input, previewId) {
  const file = input.files[0];
  if (!file) return;
  if (file.size > 3 * 1024 * 1024) { toast('Imagem muito grande. Use até 3MB.'); return; }
  const reader = new FileReader();
  reader.onload = e => {
    save(storageKey, e.target.result);
    renderFundoPreview(storageKey, previewId);
    atualizarFundoNoEditorLayout(storageKey);
    addLog('fundo_atualizado', `${currentUser.email} atualizou o fundo do documento (${storageKey})`);
    toast('Imagem de fundo salva!');
  };
  reader.readAsDataURL(file);
}

function removerFundo(storageKey, previewId) {
  localStorage.removeItem(storageKey);
  renderFundoPreview(storageKey, previewId);
  atualizarFundoNoEditorLayout(storageKey);
  toast('Fundo removido.');
}

// Atualiza o fundo direto no canvas do editor de layout, sem precisar sair e voltar da aba
function atualizarFundoNoEditorLayout(storageKey) {
  const tipo = storageKey === 'ap_fundo_certificado' ? 'cert' : 'carta';
  if (layoutEditorState) renderLayoutEditorTipo(tipo);
}

function renderFundoPreview(storageKey, previewId) {
  const wrap = document.getElementById(previewId);
  if (!wrap) return;
  const fundo = load(storageKey);
  if (fundo) {
    wrap.innerHTML = `<img src="${fundo}" style="max-width:240px; max-height:140px; border-radius:8px; border:1px solid var(--border); object-fit:cover">
      <p style="font-size:11px; color:var(--success); margin-top:6px">✅ Fundo configurado</p>`;
  } else {
    wrap.innerHTML = `<p style="font-size:12px; color:var(--text-muted)">Nenhum fundo configurado — será gerado com fundo branco.</p>`;
  }
}

// ---- Editor de layout (posição dos textos) ----
const LAYOUT_DIMS = { cert: { W: 297, H: 210, scale: 640/297 }, carta: { W: 210, H: 297, scale: 320/210 } };
const FONTES_DOC = { helvetica: { label: 'Helvetica (sem serifa)', css: "'Helvetica Neue', Arial, sans-serif" }, times: { label: 'Times (serifada)', css: "'Times New Roman', Times, serif" }, courier: { label: 'Courier (monoespaçada)', css: "'Courier New', Courier, monospace" } };
let layoutEditorState = null;
let layoutSelecionado = { cert: null, carta: null };
let layoutSimulado = { cert: 'certificado', carta: 'aprovado' };
let dragInfo = null;
let resizeInfo = null;
let layoutIdCounter = 1;

function showLayoutSubtab(tipo, btn) {
  document.querySelectorAll('.layout-editor-wrap').forEach(el => el.style.display = 'none');
  btn.parentElement.querySelectorAll('.tab').forEach(el => el.classList.remove('active'));
  document.getElementById('layout-editor-' + tipo).style.display = 'block';
  btn.classList.add('active');
}

function initLayoutEditor() {
  layoutEditorState = getLayout();
  layoutSelecionado = { cert: null, carta: null };
  renderLayoutEditorTipo('cert');
  renderLayoutEditorTipo('carta');
}

// Monta um contexto de dados de exemplo (usando textos e nome da empresa reais já configurados)
// pra simular como o documento vai ficar sem precisar de uma avaliação de verdade.
function contextoSimuladoLayout(tipo, statusSim) {
  const d = db();
  const empNome = d.empresa.nome || 'Empresa';
  const notaSim = statusSim === 'certificado' ? '10.0' : statusSim === 'parcial' ? '6.5' : statusSim === 'reprovado' ? '3.0' : '8.5';
  const tipoDocSim = getTipoDoc(statusSim, 'servico');
  const corpoTexto = aplicarTexto(d.textos[tipoDocSim] || getDefaultTextos()[tipoDocSim] || '', 'Fornecedor Exemplo Ltda', notaSim, '06/2026', empNome);
  return {
    fornecedor: { nome: 'Fornecedor Exemplo Ltda', cnpj: '12.345.678/0001-90', setor: 'Qualidade', criticidade: 'Alta', extras: {} },
    nota: notaSim, periodo: '06/2026', empresaNome: empNome, sit: statusSim, dadosEmpresa: d.empresa, corpoTexto, isCert: tipo === 'cert'
  };
}

// Gera um PDF REAL (não uma prévia aproximada) usando o estado ATUAL do editor — mesmo que ainda não tenha
// clicado em "Salvar layout". Assim dá pra comparar o resultado de verdade, e não só o preview em miniatura.
function baixarPDFTesteLayout(tipo) {
  const isCert = tipo === 'cert';
  const sitSimulada = isCert ? 'certificado' : (layoutSimulado[tipo] || 'aprovado');
  const notaSample = { certificado: 10, aprovado: 8.5, parcial: 6.0, reprovado: 3.0 }[sitSimulada];
  const fornecedorFake = { nome: 'Fornecedor Exemplo Ltda', tipo: 'servico', sit: sitSimulada, media: notaSample, cnpj: '', setor: '', criticidade: '' };
  const hoje = new Date();
  const periodoLabel = `${MESES[hoje.getMonth() + 1]}/${hoje.getFullYear()}`;
  const pdf = gerarPDFDoc(fornecedorFake, periodoLabel, layoutEditorState[tipo]);
  const blob = new Blob([pdf], { type: 'application/pdf' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Teste_Layout_${isCert ? 'Certificado' : 'Carta_' + sitSimulada}.pdf`;
  a.click();
  URL.revokeObjectURL(url);
  toast('PDF de teste gerado com o layout atual (mesmo sem clicar em Salvar)!');
}

function renderLayoutEditorTipo(tipo) {
  const dims = LAYOUT_DIMS[tipo];
  const wrap = document.getElementById('layout-editor-' + tipo);
  if (!wrap) return;
  const fundo = load(tipo === 'cert' ? 'ap_fundo_certificado' : 'ap_fundo_carta');
  const w = Math.round(dims.W * dims.scale), h = Math.round(dims.H * dims.scale);
  const opcoesStatus = tipo === 'cert'
    ? `<option value="certificado">Certificado (nota 10)</option>`
    : `<option value="aprovado">Aprovado</option><option value="parcial">Parcialmente aprovado</option><option value="reprovado">Reprovado</option>`;
  wrap.innerHTML = `
    <div class="blkedit-wrap">
      <div class="blkedit-canvas-area">
        <div class="blkedit-sim-bar">
          <label>🔄 Simular texto:</label>
          <select onchange="layoutSimulado['${tipo}']=this.value; renderLayoutBlocks('${tipo}')">${opcoesStatus}</select>
          <span style="font-size:11px; color:var(--text-muted)">— usa os textos reais configurados em Config › Textos</span>
        </div>
        <div id="layout-canvas-${tipo}" class="blkedit-canvas" style="width:${w}px; height:${h}px; background:${fundo ? `#fff url(${fundo})` : '#fff'}; background-size:100% 100%; background-position:center"></div>
        <div class="blkedit-toolbar">
          <button class="btn btn-primary btn-sm" onclick="adicionarBlocoLayout('${tipo}')">＋ Adicionar bloco</button>
          <button class="btn btn-secondary btn-sm" onclick="baixarPDFTesteLayout('${tipo}')">📄 Baixar PDF de teste</button>
          <button class="btn btn-secondary btn-sm" onclick="salvarLayout('${tipo}')">💾 Salvar layout</button>
          <button class="btn btn-secondary btn-sm" onclick="restaurarLayoutPadrao('${tipo}')">↺ Restaurar padrão</button>
        </div>
      </div>
      <div class="blkedit-sidebar" id="layout-sidebar-${tipo}"></div>
    </div>
  `;
  renderLayoutBlocks(tipo);
}

function renderLayoutBlocks(tipo) {
  const dims = LAYOUT_DIMS[tipo];
  const canvas = document.getElementById('layout-canvas-' + tipo);
  if (!canvas) return;
  const blocos = layoutEditorState[tipo].blocos;
  const ctx = contextoSimuladoLayout(tipo, layoutSimulado[tipo]);
  canvas.innerHTML = '';
  blocos.forEach(b => {
    const div = document.createElement('div');
    const selecionado = layoutSelecionado[tipo] === b.id;
    div.className = 'blkedit-block' + (selecionado ? ' selected' : '');
    const texto = b.tipo === 'fixo' ? b.conteudo : (resolveVariavelValor(b.variavel, ctx) || `{${b.variavel}}`);
    div.textContent = texto;
    const translate = b.align === 'center' ? '-50%' : b.align === 'right' ? '-100%' : '0%';
    // b.tamanho é em pontos (pt), igual ao doc.setFontSize() do jsPDF. Precisa converter
    // pt -> mm (1pt = 0.352778mm) -> px da tela (dims.scale), senão o preview fica com
    // um tamanho de fonte totalmente diferente do PDF gerado.
    const fsPx = b.tamanho * 0.352778 * dims.scale;
    // Mesmo incremento de linha usado no gerarPDFDoc (y += tamanho*0.5 + 1, em mm),
    // convertido pra px, senão textos com quebra de linha desalinham no PDF.
    const lhPx = (b.tamanho * 0.5 + 1) * dims.scale;
    // No jsPDF, x/y é a linha de base do texto; no CSS, top é o topo da caixa.
    // Aproxima a ascendente da fonte (~80% do tamanho) em vez do "-10" fixo antigo,
    // que só "acertava por acaso" num tamanho de fonte específico.
    const topPx = b.y * dims.scale - fsPx * 0.8;
    div.style.cssText = `left:${b.x*dims.scale}px; top:${topPx}px; width:${b.largura*dims.scale}px; transform:translateX(${translate}); font-family:${FONTES_DOC[b.fonte].css}; font-size:${fsPx}px; line-height:${lhPx}px; color:${b.variavel==='situacao' ? {aprovado:'#008238',parcial:'#b46400',reprovado:'#b40000'}[layoutSimulado[tipo]]||b.cor : b.cor}; font-weight:${b.negrito?'700':'400'}; font-style:${b.italico?'italic':'normal'}; text-align:${b.align};`;
    const delX = document.createElement('span');
    delX.className = 'blkedit-del'; delX.textContent = '✕';
    delX.onclick = (e) => { e.stopPropagation(); removerBlocoLayout(tipo, b.id); };
    div.appendChild(delX);
    ['left','right'].forEach(lado => {
      const h = document.createElement('span');
      h.className = 'blkedit-resize ' + lado;
      h.onmousedown = (e) => startResizeLayout(e, tipo, b.id, lado);
      div.appendChild(h);
    });
    div.addEventListener('mousedown', (e) => startDragBlock(e, tipo, b.id));
    div.addEventListener('click', (e) => { e.stopPropagation(); selecionarBlocoLayout(tipo, b.id); });
    canvas.appendChild(div);
  });
  canvas.onclick = () => selecionarBlocoLayout(tipo, null);
  renderLayoutSidebar(tipo);
}

function selecionarBlocoLayout(tipo, id) {
  layoutSelecionado[tipo] = id;
  renderLayoutBlocks(tipo);
}

function renderLayoutSidebar(tipo) {
  const wrap = document.getElementById('layout-sidebar-' + tipo);
  if (!wrap) return;
  const blocos = layoutEditorState[tipo].blocos;
  const b = blocos.find(x => x.id === layoutSelecionado[tipo]);

  if (!b) {
    wrap.innerHTML = `
      <h4>Blocos do documento</h4>
      <p class="sub">${blocos.length} bloco(s) — clique em um no documento ou na lista</p>
      ${blocos.map(bl => `
        <div class="blkedit-list-item" onclick="selecionarBlocoLayout('${tipo}','${bl.id}')">
          <div><div>${bl.label}</div><div class="bli-type">${bl.tipo === 'fixo' ? 'Texto fixo' : 'Variável · ' + (getVariaveisDoc()[bl.variavel]||{}).label}</div></div>
          <span class="bli-del" onclick="event.stopPropagation(); removerBlocoLayout('${tipo}','${bl.id}')">✕</span>
        </div>`).join('')}
    `;
    return;
  }

  const varsDisponiveis = getVariaveisDoc();
  const opcoesVars = Object.keys(varsDisponiveis).map(k => `<option value="${k}" ${b.variavel===k?'selected':''}>${varsDisponiveis[k].label}</option>`).join('');

  wrap.innerHTML = `
    <div style="display:flex; align-items:center; justify-content:space-between">
      <h4>Editando bloco</h4>
      <span style="font-size:11px; color:var(--accent); cursor:pointer; font-weight:600" onclick="selecionarBlocoLayout('${tipo}',null)">← voltar</span>
    </div>
    <p class="sub">Alterações aparecem no documento em tempo real</p>

    <div class="blkedit-prop"><label>Nome do bloco</label><input type="text" value="${b.label}" onchange="atualizarBlocoLayout('${tipo}','label',this.value)"></div>

    <div class="blkedit-prop">
      <label>Tipo de conteúdo</label>
      <div class="blkedit-seg">
        <button class="${b.tipo==='fixo'?'active':''}" onclick="atualizarBlocoLayout('${tipo}','tipo','fixo')">Texto fixo</button>
        <button class="${b.tipo==='variavel'?'active':''}" onclick="atualizarBlocoLayout('${tipo}','tipo','variavel')">Variável dinâmica</button>
      </div>
    </div>

    ${b.tipo === 'fixo'
      ? `<div class="blkedit-prop"><label>Texto</label><textarea onchange="atualizarBlocoLayout('${tipo}','conteudo',this.value)">${b.conteudo||''}</textarea></div>`
      : `<div class="blkedit-prop"><label>Variável associada</label><select onchange="atualizarBlocoLayout('${tipo}','variavel',this.value)">${opcoesVars}</select></div>`}

    <div class="blkedit-prop"><label>Fonte</label>
      <select onchange="atualizarBlocoLayout('${tipo}','fonte',this.value)">
        ${Object.keys(FONTES_DOC).map(f => `<option value="${f}" ${b.fonte===f?'selected':''}>${FONTES_DOC[f].label}</option>`).join('')}
      </select>
    </div>

    <div class="blkedit-row">
      <div class="blkedit-prop"><label>Tamanho</label><input type="text" value="${b.tamanho}" onchange="atualizarBlocoLayout('${tipo}','tamanho',parseFloat(this.value)||b.tamanho)"></div>
      <div class="blkedit-prop"><label>Cor</label>
        <div class="blkedit-color-row">
          <input type="color" value="${b.cor}" onchange="atualizarBlocoLayout('${tipo}','cor',this.value)">
          <input type="text" value="${b.cor}" onchange="atualizarBlocoLayout('${tipo}','cor',this.value)">
        </div>
      </div>
    </div>
    ${b.variavel === 'situacao' ? `<p style="font-size:10.5px; color:var(--text-muted); margin-top:-8px; margin-bottom:12px">💡 Essa variável já muda de cor sozinha (verde/laranja/vermelho) conforme o resultado — a cor acima só vale se não for essa variável.</p>` : ''}

    <div class="blkedit-prop"><label>Estilo</label>
      <div class="blkedit-toggle">
        <button class="${b.negrito?'active':''}" onclick="atualizarBlocoLayout('${tipo}','negrito',${!b.negrito})"><b>B</b> Negrito</button>
        <button class="${b.italico?'active':''}" onclick="atualizarBlocoLayout('${tipo}','italico',${!b.italico})"><i>I</i> Itálico</button>
      </div>
    </div>

    <div class="blkedit-prop"><label>Alinhamento</label>
      <div class="blkedit-seg">
        <button class="${b.align==='left'?'active':''}" onclick="atualizarBlocoLayout('${tipo}','align','left')">Esquerda</button>
        <button class="${b.align==='center'?'active':''}" onclick="atualizarBlocoLayout('${tipo}','align','center')">Centro</button>
        <button class="${b.align==='right'?'active':''}" onclick="atualizarBlocoLayout('${tipo}','align','right')">Direita</button>
      </div>
    </div>

    <details class="blkedit-details">
      <summary>Posição e largura exatas (mm)</summary>
      <div class="blkedit-row3">
        <div class="blkedit-prop" style="margin-bottom:0"><label>X</label><input type="text" value="${b.x}" onchange="atualizarBlocoLayout('${tipo}','x',parseFloat(this.value)||b.x)"></div>
        <div class="blkedit-prop" style="margin-bottom:0"><label>Y</label><input type="text" value="${b.y}" onchange="atualizarBlocoLayout('${tipo}','y',parseFloat(this.value)||b.y)"></div>
        <div class="blkedit-prop" style="margin-bottom:0"><label>Largura</label><input type="text" value="${b.largura}" onchange="atualizarBlocoLayout('${tipo}','largura',parseFloat(this.value)||b.largura)"></div>
      </div>
      <p style="font-size:11px; color:var(--text-muted); margin-top:8px">💡 Também dá pra arrastar as alcinhas azuis nas laterais do bloco no documento.</p>
    </details>

    <div style="height:1px; background:var(--border); margin:14px 0"></div>
    <button class="btn btn-danger btn-sm btn-block" onclick="removerBlocoLayout('${tipo}','${b.id}')">🗑 Remover bloco</button>
  `;
}

function atualizarBlocoLayout(tipo, campo, valor) {
  const b = layoutEditorState[tipo].blocos.find(x => x.id === layoutSelecionado[tipo]);
  if (!b) return;
  b[campo] = valor;
  if (campo === 'tipo' && valor === 'variavel' && !b.variavel) b.variavel = 'fornecedor';
  renderLayoutBlocks(tipo);
}

function adicionarBlocoLayout(tipo) {
  const novo = { id: 'custom' + (layoutIdCounter++), label: 'Novo texto', tipo: 'fixo', conteudo: 'Clique para editar este texto', fonte: 'helvetica', tamanho: 12, cor: '#333333', negrito: false, italico: false, align: 'left', x: 30, y: 100, largura: 140 };
  layoutEditorState[tipo].blocos.push(novo);
  selecionarBlocoLayout(tipo, novo.id);
  toast('Bloco adicionado — arraste ou puxe as bordas pra ajustar');
}

function removerBlocoLayout(tipo, id) {
  layoutEditorState[tipo].blocos = layoutEditorState[tipo].blocos.filter(b => b.id !== id);
  if (layoutSelecionado[tipo] === id) layoutSelecionado[tipo] = null;
  renderLayoutBlocks(tipo);
  toast('Bloco removido');
}

function startDragBlock(e, tipo, id) {
  e.preventDefault(); e.stopPropagation();
  selecionarBlocoLayout(tipo, id);
  const rect = document.getElementById('layout-canvas-' + tipo).getBoundingClientRect();
  dragInfo = { tipo, id, rect };
  document.addEventListener('mousemove', onDragBlock);
  document.addEventListener('mouseup', endDragBlock);
}
function onDragBlock(e) {
  if (!dragInfo) return;
  const { rect, tipo, id } = dragInfo;
  const dims = LAYOUT_DIMS[tipo];
  const b = layoutEditorState[tipo].blocos.find(x => x.id === id);
  let xPx = Math.max(0, Math.min(rect.width, e.clientX - rect.left));
  let yPx = Math.max(0, Math.min(rect.height, e.clientY - rect.top));
  b.x = +(xPx / dims.scale).toFixed(1);
  b.y = +(yPx / dims.scale).toFixed(1);
  renderLayoutBlocks(tipo);
}
function endDragBlock() {
  dragInfo = null;
  document.removeEventListener('mousemove', onDragBlock);
  document.removeEventListener('mouseup', endDragBlock);
}

function startResizeLayout(e, tipo, id, lado) {
  e.preventDefault(); e.stopPropagation();
  selecionarBlocoLayout(tipo, id);
  const b = layoutEditorState[tipo].blocos.find(x => x.id === id);
  resizeInfo = { tipo, id, lado, startX: e.clientX, startLargura: b.largura };
  document.addEventListener('mousemove', onResizeLayout);
  document.addEventListener('mouseup', endResizeLayout);
}
function onResizeLayout(e) {
  if (!resizeInfo) return;
  const { tipo, id, lado, startX, startLargura } = resizeInfo;
  const dims = LAYOUT_DIMS[tipo];
  const b = layoutEditorState[tipo].blocos.find(x => x.id === id);
  const deltaMm = ((lado === 'right' ? 1 : -1) * (e.clientX - startX)) / dims.scale;
  b.largura = Math.max(20, Math.min(dims.W - 10, +(startLargura + deltaMm).toFixed(1)));
  renderLayoutBlocks(tipo);
}
function endResizeLayout() {
  resizeInfo = null;
  document.removeEventListener('mousemove', onResizeLayout);
  document.removeEventListener('mouseup', endResizeLayout);
}

function salvarLayout(tipo) {
  save('ap_layout', layoutEditorState);
  addLog('layout_atualizado', `${currentUser.email} atualizou o layout do documento (${tipo === 'cert' ? 'certificado' : 'carta'})`);
  toast('Layout salvo!');
}

function restaurarLayoutPadrao(tipo) {
  if (!confirm('Restaurar as posições padrão deste documento? Blocos personalizados que você criou serão removidos.')) return;
  layoutEditorState[tipo] = JSON.parse(JSON.stringify(getLayoutDefaults()[tipo]));
  layoutSelecionado[tipo] = null;
  renderLayoutBlocks(tipo);
}

// ---- Campos personalizados do fornecedor ----
function renderCamposFornecedorLista() {
  const d = db();
  const wrap = document.getElementById('campos-fornecedor-lista');
  if (!wrap) return;
  if (!d.camposFornecedorCustom.length) { wrap.innerHTML = '<p style="font-size:12px; color:var(--text-muted)">Nenhum campo personalizado ainda.</p>'; return; }
  wrap.innerHTML = `<table><thead><tr><th>Rótulo</th><th>Chave</th><th>Tipo</th><th></th></tr></thead><tbody>
    ${d.camposFornecedorCustom.map(c => `<tr>
      <td>${c.label}</td><td style="color:var(--text-muted)">${c.chave}</td><td>${c.tipo === 'select' ? 'Lista' : c.tipo === 'data' ? 'Data' : 'Texto'}</td>
      <td><button class="btn btn-danger btn-sm" onclick="removeCampoFornecedorCustom('${c.chave}')">Remover</button></td>
    </tr>`).join('')}
  </tbody></table>`;
}

async function addCampoFornecedorCustom() {
  const chave = document.getElementById('ncf-chave').value.trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, '_');
  const label = document.getElementById('ncf-label').value.trim();
  const tipo = document.getElementById('ncf-tipo').value;
  const opcoes = document.getElementById('ncf-opcoes').value.split(',').map(s => s.trim()).filter(Boolean);
  if (!chave || !label) { toast('Informe a chave e o rótulo do campo.'); return; }
  const d = db();
  if (d.camposFornecedorCustom.some(c => c.chave === chave)) { toast('Já existe um campo com essa chave.'); return; }

  const novaLista = [...d.camposFornecedorCustom, { chave, label, tipo, opcoes: tipo === 'select' ? opcoes : [] }];

  const { error } = await supabaseClient
    .from('empresas')
    .update({ campos_fornecedor_custom: novaLista })
    .eq('id', currentUser.empresaId);

  if (error) { toast('Erro ao salvar campo: ' + error.message); return; }

  empresaConfigCache.campos_fornecedor_custom = novaLista;
  addLog('campo_fornecedor_criado', `${currentUser.email} criou o campo personalizado "${label}" para fornecedores`);
  document.getElementById('ncf-chave').value = '';
  document.getElementById('ncf-label').value = '';
  document.getElementById('ncf-opcoes').value = '';
  renderCamposFornecedorLista();
  toast('Campo adicionado! Já aparece no cadastro de fornecedores.');
}

async function removeCampoFornecedorCustom(chave) {
  if (!confirm('Remover este campo? Os valores já preenchidos nos fornecedores serão mantidos, mas o campo não aparecerá mais nos formulários.')) return;
  const d = db();
  const novaLista = d.camposFornecedorCustom.filter(c => c.chave !== chave);

  const { error } = await supabaseClient
    .from('empresas')
    .update({ campos_fornecedor_custom: novaLista })
    .eq('id', currentUser.empresaId);

  if (error) { toast('Erro ao remover campo: ' + error.message); return; }

  empresaConfigCache.campos_fornecedor_custom = novaLista;
  addLog('campo_fornecedor_removido', `${currentUser.email} removeu um campo personalizado de fornecedores`);
  renderCamposFornecedorLista();
  toast('Campo removido.');
}

// ---- Tipos de documento ----
function renderTiposDocumentoLista() {
  const d = db();
  const wrap = document.getElementById('tipos-documento-lista');
  if (!wrap) return;
  if (!d.tiposDocumento.length) { wrap.innerHTML = '<p style="font-size:12px; color:var(--text-muted)">Nenhum tipo cadastrado ainda.</p>'; return; }
  wrap.innerHTML = d.tiposDocumento.map(t => `
    <span style="display:inline-flex; align-items:center; gap:8px; padding:6px 8px 6px 14px; border:1px solid var(--border-strong); border-radius:999px; font-size:12.5px; background:var(--surface)">
      ${t}
      <button onclick="removeTipoDocumento('${t.replace(/'/g, "\\'")}')" style="border:none; background:var(--surface2); color:var(--text-muted); width:18px; height:18px; border-radius:50%; cursor:pointer; font-size:12px; line-height:1; display:flex; align-items:center; justify-content:center" title="Remover">✕</button>
    </span>
  `).join('');
}

function addTipoDocumento() {
  const input = document.getElementById('ntd-nome');
  const nome = input.value.trim();
  if (!nome) { toast('Informe o nome do tipo de documento.'); return; }
  const d = db();
  if (d.tiposDocumento.some(t => t.toLowerCase() === nome.toLowerCase())) { toast('Esse tipo já está cadastrado.'); return; }
  d.tiposDocumento.push(nome);
  save('ap_tipos_documento', d.tiposDocumento);
  addLog('tipo_documento_criado', `${currentUser.email} cadastrou o tipo de documento "${nome}"`);
  input.value = '';
  renderTiposDocumentoLista();
  toast('Tipo de documento adicionado!');
}

function removeTipoDocumento(nome) {
  const d = db();
  d.tiposDocumento = d.tiposDocumento.filter(t => t !== nome);
  save('ap_tipos_documento', d.tiposDocumento);
  addLog('tipo_documento_removido', `${currentUser.email} removeu o tipo de documento "${nome}"`);
  renderTiposDocumentoLista();
  toast('Tipo removido.');
}

// inicializar previews/editor ao entrar nas abas
const _origShowConfigTabAd = showConfigTabAd;
showConfigTabAd = function(tab, btn) {
  _origShowConfigTabAd(tab, btn);
  if (tab === 'layout') {
    renderFundoPreview('ap_fundo_certificado', 'fundo-cert-preview');
    renderFundoPreview('ap_fundo_carta', 'fundo-carta-preview');
    initLayoutEditor();
  }
  if (tab === 'camposfor') {
    renderCamposFornecedorLista();
  }
  if (tab === 'tiposdoc') {
    renderTiposDocumentoLista();
  }
};
